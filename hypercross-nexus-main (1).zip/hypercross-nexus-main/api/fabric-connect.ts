import type { IncomingMessage, ServerResponse } from "http";

function validateUrl(raw: string): URL | null {
  try {
    const u = new URL(raw);
    if (u.protocol !== "https:" && u.protocol !== "http:") return null;
    return u;
  } catch {
    return null;
  }
}

async function readBody(req: IncomingMessage): Promise<any> {
  return new Promise((resolve) => {
    let data = "";
    req.on("data", (chunk) => (data += chunk));
    req.on("end", () => {
      try { resolve(JSON.parse(data)); } catch { resolve({}); }
    });
  });
}

export default async function handler(req: IncomingMessage, res: ServerResponse) {
  res.setHeader("Content-Type", "application/json");

  if (req.method !== "POST") {
    res.writeHead(405);
    return res.end(JSON.stringify({ error: "Method not allowed" }));
  }

  const body = await readBody(req);
  const { endpoint, username, password } = body ?? {};

  if (!endpoint || !username || !password) {
    res.writeHead(400);
    return res.end(JSON.stringify({ error: "endpoint, username, and password are required" }));
  }

  const url = validateUrl(endpoint);
  if (!url) {
    res.writeHead(400);
    return res.end(JSON.stringify({ error: "Invalid endpoint URL — must start with https:// or http://" }));
  }

  const auth = "Basic " + Buffer.from(`${username}:${password}`).toString("base64");
  const base = url.origin + url.pathname.replace(/\/+$/, "");

  try {
    const r = await fetch(`${base}/channels`, {
      headers: { Authorization: auth, "Content-Type": "application/json" },
      signal: AbortSignal.timeout(10000),
    });

    const text = await r.text();
    let data: any;
    try { data = JSON.parse(text); } catch { data = text; }

    res.writeHead(r.ok ? 200 : r.status);
    return res.end(JSON.stringify(
      r.ok
        ? { connected: true, channels: data }
        : { connected: false, error: `Node returned HTTP ${r.status}`, details: data }
    ));
  } catch (err: any) {
    res.writeHead(503);
    return res.end(JSON.stringify({ connected: false, error: "Could not reach endpoint: " + (err?.message ?? "unknown error") }));
  }
}
