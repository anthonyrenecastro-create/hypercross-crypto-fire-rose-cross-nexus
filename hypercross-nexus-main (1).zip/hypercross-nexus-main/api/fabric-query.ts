import type { IncomingMessage, ServerResponse } from "http";

function validateUrl(raw: string): URL | null {
  try {
    const u = new URL(raw);
    if (u.protocol !== "https:" && u.protocol !== "http:") return null;
    return u;
  } catch {
    return null;
  }
}

async function readBody(req: IncomingMessage): Promise<any> {
  return new Promise((resolve) => {
    let data = "";
    req.on("data", (chunk) => (data += chunk));
    req.on("end", () => {
      try { resolve(JSON.parse(data)); } catch { resolve({}); }
    });
  });
}

export default async function handler(req: IncomingMessage, res: ServerResponse) {
  res.setHeader("Content-Type", "application/json");

  if (req.method !== "POST") {
    res.writeHead(405);
    return res.end(JSON.stringify({ error: "Method not allowed" }));
  }

  const body = await readBody(req);
  const { endpoint, username, password, channel, chaincode, func, args } = body ?? {};

  if (!endpoint || !username || !password || !channel || !chaincode || !func) {
    res.writeHead(400);
    return res.end(JSON.stringify({ error: "endpoint, username, password, channel, chaincode, and func are required" }));
  }

  const url = validateUrl(endpoint);
  if (!url) {
    res.writeHead(400);
    return res.end(JSON.stringify({ error: "Invalid endpoint URL — must start with https:// or http://" }));
  }

  const auth = "Basic " + Buffer.from(`${username}:${password}`).toString("base64");
  const base = url.origin + url.pathname.replace(/\/+$/, "");

  // Safely parse args — accepts JSON array string or comma-separated values
  let parsedArgs: string[] = [];
  if (Array.isArray(args)) {
    parsedArgs = args.map(String);
  } else if (typeof args === "string" && args.trim()) {
    try {
      const parsed = JSON.parse(args);
      parsedArgs = Array.isArray(parsed) ? parsed.map(String) : [String(parsed)];
    } catch {
      parsedArgs = args.split(",").map((s) => s.trim()).filter(Boolean);
    }
  }

  const payload = {
    headers: { type: "Query", channel, chaincode },
    func,
    args: parsedArgs,
  };

  try {
    const r = await fetch(`${base}/query`, {
      method: "POST",
      headers: { Authorization: auth, "Content-Type": "application/json" },
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(15000),
    });

    const text = await r.text();
    let data: any;
    try { data = JSON.parse(text); } catch { data = text; }

    res.writeHead(r.status);
    return res.end(JSON.stringify(data));
  } catch (err: any) {
    res.writeHead(503);
    return res.end(JSON.stringify({ error: "Could not reach endpoint: " + (err?.message ?? "unknown error") }));
  }
}
