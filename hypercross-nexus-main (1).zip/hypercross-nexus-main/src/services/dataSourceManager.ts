import axios from 'axios';
import type { AxiosInstance } from 'axios';
import whiteLabelConfig from '../../config/whiteLabelConfig.json';

interface FabricConnection {
  endpoint: string;
  username: string;
  password: string;
}

interface DataSourceConfig {
  type: string;
  baseUrl: string;
  timeout?: number;
}

interface MarketPriceMap {
  [symbol: string]: {
    usd: number;
  };
}

class DataSourceManager {
  private fabricConnections: Map<string, FabricConnection> = new Map();
  private httpClients: Map<string, AxiosInstance> = new Map();
  private config = whiteLabelConfig;
  private liveStrictMode: boolean;

  constructor() {
    this.liveStrictMode = this.envFlagEnabled(process.env.LIVE_FEED_STRICT) || this.envFlagEnabled(process.env.KALEIDO_LIVE_STRICT);
    this.initializeDataSources();
  }

  private envFlagEnabled(value: string | undefined): boolean {
    if (!value) return false;
    const normalized = value.trim().toLowerCase();
    return normalized === '1' || normalized === 'true' || normalized === 'yes' || normalized === 'on';
  }

  private getEnv(name: string): string | null {
    const v = process.env[name]?.trim();
    return v ? v : null;
  }

  private getKaleidoAuthHeader(): string | undefined {
    const key = this.getEnv('KALEIDO_API_KEY');
    if (!key) return undefined;
    if (key.toLowerCase().startsWith('basic ')) return key;
    return 'Basic ' + Buffer.from(key).toString('base64');
  }

  private async fetchLive(url: string, params?: Record<string, any>): Promise<any> {
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    const auth = this.getKaleidoAuthHeader();
    if (auth) headers.Authorization = auth;
    const res = await axios.get(url, { headers, params, timeout: 10000 });
    return res.data;
  }

  private toArrayPayload(data: any): any[] | null {
    if (Array.isArray(data)) return data;
    if (Array.isArray(data?.items)) return data.items;
    if (Array.isArray(data?.data)) return data.data;
    return null;
  }

  private initializeDataSources() {
    // Initialize HTTP clients for external APIs
    for (const [name, dsConfig] of Object.entries(this.config.datasources)) {
      if ((dsConfig as any).type === 'rest') {
        const client = axios.create({
          baseURL: (dsConfig as any).baseUrl,
          timeout: (dsConfig as any).timeout || 5000,
        });
        this.httpClients.set(name, client);
      }
    }
  }

  async setFabricConnection(endpoint: string, username: string, password: string) {
    this.fabricConnections.set('default', { endpoint, username, password });
  }

  private getFabricConnection(): FabricConnection | null {
    return this.fabricConnections.get('default') ?? null;
  }

  private async queryFabric(channel: string, chaincode: string, func: string, args: string[] = []): Promise<any[] | null> {
    const conn = this.getFabricConnection();
    if (!conn) return null;

    const auth = 'Basic ' + Buffer.from(`${conn.username}:${conn.password}`).toString('base64');
    const baseUrl = conn.endpoint.replace(/\/+$/, '');
    const payload = {
      headers: { type: 'Query', channel, chaincode },
      func,
      args,
    };

    const res = await axios.post(`${baseUrl}/query`, payload, {
      headers: { Authorization: auth, 'Content-Type': 'application/json' },
      timeout: 10000,
    });

    return Array.isArray(res.data) ? res.data : null;
  }

  private getDemoAssets(channel: string): any[] {
    if (channel === 'fundraising-channel') {
      return [
        { name: 'HXT Seed Round', symbol: 'HXT', type: 'Campaign', supply: '2000000', channel },
        { name: 'NexusBond Series A', symbol: 'NXB', type: 'Campaign', supply: '5000000', channel },
        { name: 'GreenCredit IDO', symbol: 'GCR', type: 'Campaign', supply: '800000', channel },
      ];
    }

    return [
      { name: 'HyperToken', symbol: 'HXT', supply: '10000000', type: 'Fungible', channel },
      { name: 'NexusBond', symbol: 'NXB', supply: '500000', type: 'Fungible', channel },
      { name: 'AssetShare #001', symbol: 'AS1', supply: '1', type: 'Non-Fungible', channel },
    ];
  }

  private getDemoRWAs(): any[] {
    return [
      { name: '125 Wall St, NYC', type: 'Real Estate', valuation: '4200000', tokens: '4200', yield: '6.8', kyc: true },
      { name: 'Gold Bar Lot #4422', type: 'Commodities', valuation: '980000', tokens: '980', yield: '3.1', kyc: true },
      { name: 'US T-Bill 2025-Q3', type: 'Treasury Bills', valuation: '1000000', tokens: '10000', yield: '5.2', kyc: false },
    ];
  }

  private getDemoNFTs(): any[] {
    return [
      { name: 'Nexus Genesis #001', collection: 'Nexus Genesis', owner: '0x1a2b...3c4d' },
      { name: 'HyperNode Alpha', collection: 'HyperNodes', owner: '0x5e6f...7g8h' },
      { name: 'Chain Chaos #042', collection: 'Chain Chaos', owner: '0x9i0j...1k2l' },
      { name: 'Stability Wave #7', collection: 'Stability Waves', owner: '0x3m4n...5o6p' },
    ];
  }

  private getDemoSportsEvents(): any[] {
    return [
      { home: 'Lakers', away: 'Celtics', sport: 'NBA', homeOdds: 1.85, awayOdds: 1.95, drawOdds: null, status: 'Live', time: 'Q3 08:42' },
      { home: 'Man City', away: 'Arsenal', sport: 'EPL', homeOdds: 1.7, awayOdds: 2.1, drawOdds: 3.5, status: 'Live', time: "67'" },
      { home: 'Djokovic', away: 'Alcaraz', sport: 'Tennis', homeOdds: 1.55, awayOdds: 2.4, drawOdds: null, status: 'Starting', time: 'In 15 min' },
    ];
  }

  private getDemoMiningPools(): any[] {
    return [
      { name: 'Nexus Mining Pool Alpha', algo: 'SHA-256', hashrate: '42.8 PH/s', workers: 184, fee: '1.5%', earnings24h: '0.0042 BTC', status: 'Active' },
      { name: 'HyperCross ETH Pool', algo: 'Ethash', hashrate: '820 GH/s', workers: 67, fee: '1.0%', earnings24h: '0.91 ETH', status: 'Active' },
      { name: 'Kaleido Testnet Pool', algo: 'Custom PoW', hashrate: '12 TH/s', workers: 12, fee: '0%', earnings24h: '—', status: 'Test' },
    ];
  }

  private getDemoMarketPrices(symbols: string[]): MarketPriceMap {
    const defaults: MarketPriceMap = {
      bitcoin: { usd: 67240 },
      ethereum: { usd: 3421.8 },
    };

    return symbols.reduce<MarketPriceMap>((result, symbol) => {
      const key = symbol.toLowerCase();
      result[key] = defaults[key] ?? { usd: 0 };
      return result;
    }, {});
  }

  // ── DIGITAL ASSETS ──
  async getAssets(channel: string = 'default-channel'): Promise<any[]> {
    const liveAssetsUrl = this.getEnv('KALEIDO_ASSETS_URL');
    if (liveAssetsUrl) {
      try {
        const data = await this.fetchLive(liveAssetsUrl, { channel });
        const payload = this.toArrayPayload(data);
        if (!payload) throw new Error('Invalid assets payload shape');
        return payload;
      } catch (err) {
        console.error('Failed to fetch live assets:', err);
        if (this.liveStrictMode) throw err;
      }
    }

    try {
      const assets = await this.queryFabric(channel, 'assets', 'GetAllAssets');
      return assets && assets.length > 0 ? assets : this.getDemoAssets(channel);
    } catch (err) {
      console.error('Failed to fetch assets:', err);
      if (this.liveStrictMode) throw err;
      return this.getDemoAssets(channel);
    }
  }

  async getAssetBySymbol(symbol: string, channel: string = 'default-channel'): Promise<any> {
    const liveAssetBySymbolUrl = this.getEnv('KALEIDO_ASSET_BY_SYMBOL_URL');
    if (liveAssetBySymbolUrl) {
      try {
        const data = await this.fetchLive(liveAssetBySymbolUrl, { symbol, channel });
        return data?.item ?? data;
      } catch (err) {
        console.error('Failed to fetch live asset by symbol:', err);
        if (this.liveStrictMode) throw err;
      }
    }

    try {
      const conn = this.getFabricConnection();
      if (!conn) {
        if (this.liveStrictMode) throw new Error('No live data source configured for asset lookup');
        return this.getDemoAssets(channel).find((asset) => asset.symbol === symbol) ?? null;
      }

      const auth = 'Basic ' + Buffer.from(`${conn.username}:${conn.password}`).toString('base64');
      const baseUrl = conn.endpoint.replace(/\/+$/, '');
      const payload = {
        headers: { type: 'Query', channel, chaincode: 'assets' },
        func: 'ReadAsset',
        args: [symbol],
      };

      const res = await axios.post(`${baseUrl}/query`, payload, {
        headers: { Authorization: auth, 'Content-Type': 'application/json' },
        timeout: 10000,
      });

      return res.data;
    } catch (err) {
      console.error('Failed to fetch asset:', err);
      if (this.liveStrictMode) throw err;
      return this.getDemoAssets(channel).find((asset) => asset.symbol === symbol) ?? null;
    }
  }

  // ── TRADING DATA ──
  async getMarketPrices(symbols: string[]): Promise<MarketPriceMap> {
    const liveMarketUrl = this.getEnv('KALEIDO_MARKET_PRICES_URL');
    if (liveMarketUrl) {
      try {
        const data = await this.fetchLive(liveMarketUrl, { symbols: symbols.join(',') });
        if (data && typeof data === 'object') return data as MarketPriceMap;
        throw new Error('Invalid market prices payload shape');
      } catch (err) {
        console.error('Failed to fetch live market prices:', err);
        if (this.liveStrictMode) throw err;
      }
    }

    try {
      const coingecko = this.httpClients.get('coingecko');
      if (!coingecko) return this.getDemoMarketPrices(symbols);

      const ids = symbols.map(s => s.toLowerCase()).join(',');
      const res = await coingecko.get('/simple/price', {
        params: {
          ids,
          vs_currencies: 'usd',
          include_market_cap: 'true',
          include_24hr_vol: 'true',
        },
      });

      return res.data;
    } catch (err) {
      console.error('Failed to fetch market prices:', err);
      if (this.liveStrictMode) throw err;
      return this.getDemoMarketPrices(symbols);
    }
  }

  async getLiveOrderBook(instrument: string): Promise<any> {
    const liveOrderbookUrl = this.getEnv('KALEIDO_ORDERBOOK_URL');
    if (liveOrderbookUrl) {
      try {
        const resolvedUrl = liveOrderbookUrl.includes('{instrument}')
          ? liveOrderbookUrl.replace('{instrument}', encodeURIComponent(instrument))
          : liveOrderbookUrl;
        const data = await this.fetchLive(resolvedUrl, liveOrderbookUrl.includes('{instrument}') ? undefined : { instrument });
        return data;
      } catch (err) {
        console.error('Failed to fetch live order book:', err);
        if (this.liveStrictMode) throw err;
      }
    }

    try {
      // Placeholder: could integrate with real exchange APIs (Binance, Deribit, etc.)
      // For now, return mock structure that frontend can handle
      return {
        bids: [],
        asks: [],
        timestamp: new Date().toISOString(),
      };
    } catch (err) {
      console.error('Failed to fetch order book:', err);
      if (this.liveStrictMode) throw err;
      return null;
    }
  }

  // ── SPORTS DATA ──
  async getLiveSportsEvents(): Promise<any[]> {
    const liveSportsUrl = this.getEnv('KALEIDO_SPORTS_EVENTS_URL');
    if (liveSportsUrl) {
      try {
        const data = await this.fetchLive(liveSportsUrl);
        const payload = this.toArrayPayload(data);
        if (!payload) throw new Error('Invalid sports payload shape');
        return payload;
      } catch (err) {
        console.error('Failed to fetch live sports events:', err);
        if (this.liveStrictMode) throw err;
      }
    }

    try {
      return this.getDemoSportsEvents();
    } catch (err) {
      console.error('Failed to fetch sports events:', err);
      if (this.liveStrictMode) throw err;
      return this.getDemoSportsEvents();
    }
  }

  // ── MINING ──
  async getMiningPoolStats(): Promise<any[]> {
    const liveMiningUrl = this.getEnv('KALEIDO_MINING_STATS_URL');
    if (liveMiningUrl) {
      try {
        const data = await this.fetchLive(liveMiningUrl);
        const payload = this.toArrayPayload(data);
        if (!payload) throw new Error('Invalid mining payload shape');
        return payload;
      } catch (err) {
        console.error('Failed to fetch live mining stats:', err);
        if (this.liveStrictMode) throw err;
      }
    }

    try {
      return this.getDemoMiningPools();
    } catch (err) {
      console.error('Failed to fetch mining stats:', err);
      if (this.liveStrictMode) throw err;
      return this.getDemoMiningPools();
    }
  }

  // ── RWA ──
  async getRWAssets(channel: string = 'rwa-channel'): Promise<any[]> {
    const liveRwaUrl = this.getEnv('KALEIDO_RWA_URL');
    if (liveRwaUrl) {
      try {
        const data = await this.fetchLive(liveRwaUrl, { channel });
        const payload = this.toArrayPayload(data);
        if (!payload) throw new Error('Invalid RWA payload shape');
        return payload;
      } catch (err) {
        console.error('Failed to fetch live RWAs:', err);
        if (this.liveStrictMode) throw err;
      }
    }

    try {
      const rwas = await this.queryFabric(channel, 'rwa', 'GetAllRWAs');
      return rwas && rwas.length > 0 ? rwas : this.getDemoRWAs();
    } catch (err) {
      console.error('Failed to fetch RWAs:', err);
      if (this.liveStrictMode) throw err;
      return this.getDemoRWAs();
    }
  }

  // ── NFT ──
  async getNFTs(channel: string = 'nft-channel'): Promise<any[]> {
    const liveNftUrl = this.getEnv('KALEIDO_NFT_URL');
    if (liveNftUrl) {
      try {
        const data = await this.fetchLive(liveNftUrl, { channel });
        const payload = this.toArrayPayload(data);
        if (!payload) throw new Error('Invalid NFT payload shape');
        return payload;
      } catch (err) {
        console.error('Failed to fetch live NFTs:', err);
        if (this.liveStrictMode) throw err;
      }
    }

    try {
      const nfts = await this.queryFabric(channel, 'nft', 'GetAllNFTs');
      return nfts && nfts.length > 0 ? nfts : this.getDemoNFTs();
    } catch (err) {
      console.error('Failed to fetch NFTs:', err);
      if (this.liveStrictMode) throw err;
      return this.getDemoNFTs();
    }
  }
}

export const dataSourceManager = new DataSourceManager();
