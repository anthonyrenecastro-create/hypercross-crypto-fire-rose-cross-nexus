import "dotenv/config";
import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import crypto from "crypto";
import whiteLabelConfig from "./config/whiteLabelConfig.json";
import { queries } from "./src/db";
import { BlockchainProviderFactory } from "./server/blockchain/BlockchainProviderFactory";
import {
  hashPassword,
  verifyPassword,
  createSessionToken,
  getSessionCookieName,
  getSessionCookieOptions,
  getSessionExpiration,
  clearSessionCookie,
  requireAuth,
  requireRole,
  requirePermission,
  requireOrganizationAccess,
  isValidRole,
  type AuthenticatedRequest,
} from "./server/auth";

const ENCRYPTION_KEY = process.env.ENCRYPTION_KEY || crypto.createHash("sha256").update("hypercross-default-key").digest("hex").slice(0, 32);

function encryptValue(value: string): string {
  const iv = crypto.randomBytes(16);
  const key = crypto.createHash("sha256").update(ENCRYPTION_KEY).digest();
  const cipher = crypto.createCipheriv("aes-256-cbc", key, iv);
  const encrypted = Buffer.concat([cipher.update(value, "utf8"), cipher.final()]);
  return `${iv.toString("hex")}:${encrypted.toString("hex")}`;
}

function decryptValue(value: string): string {
  const [ivHex, encryptedHex] = value.split(":");
  if (!ivHex || !encryptedHex) return value;
  const iv = Buffer.from(ivHex, "hex");
  const key = crypto.createHash("sha256").update(ENCRYPTION_KEY).digest();
  const decipher = crypto.createDecipheriv("aes-256-cbc", key, iv);
  const decrypted = Buffer.concat([decipher.update(Buffer.from(encryptedHex, "hex")), decipher.final()]);
  return decrypted.toString("utf8");
}

function storeEncryptedOAuthToken(provider: string, accessToken: string, refreshToken?: string | null, expiresAt?: string | null, scope?: string, tokenType?: string, metadata?: Record<string, unknown>) {
  const tokenId = `oauth_${provider}_${Date.now()}`;
  queries.oauthTokens.upsert.run(
    tokenId,
    provider,
    encryptValue(accessToken),
    refreshToken ? encryptValue(refreshToken) : null,
    expiresAt ?? null,
    scope ?? "",
    tokenType ?? "Bearer",
    JSON.stringify(metadata ?? {})
  );
}

function getStoredOAuthToken(provider: string): any | null {
  const row = queries.oauthTokens.getByProvider.get(provider) as any;
  if (!row) return null;
  return {
    ...row,
    accessToken: row.accessToken ? decryptValue(row.accessToken) : null,
    refreshToken: row.refreshToken ? decryptValue(row.refreshToken) : null,
  };
}

function recordIdempotency(resource: string, key: string, payload: unknown): boolean {
  const existing = queries.idempotency.get.get(resource, key) as any;
  if (existing) return false;
  queries.idempotency.set.run(crypto.randomUUID(), resource, key, JSON.stringify(payload));
  return true;
}

function getWebhookEventId(event: any): string {
  return String(event?.id ?? event?.resource?.id ?? event?.event_id ?? `${event?.type ?? "webhook"}-${Date.now()}`);
}

function checkDuplicateWebhook(resource: string, eventId: string): boolean {
  const key = `${resource}:${eventId}`;
  return !recordIdempotency(resource, key, { eventId });
}

function requireVerifiedStripeSignature(payload: Buffer, signature: string | undefined, secret: string | undefined): { ok: boolean; event?: any; error?: string } {
  if (!secret) return { ok: false, error: "Missing Stripe webhook secret." };
  if (!signature) return { ok: false, error: "Missing stripe-signature header." };

  const parts = signature.split(",");
  const tPart = parts.find((p) => p.startsWith("t="));
  const v1Part = parts.find((p) => p.startsWith("v1="));
  if (!tPart || !v1Part) return { ok: false, error: "Malformed stripe signature header." };

  const timestamp = tPart.slice(2);
  const expectedSignature = v1Part.slice(3);
  const signedPayload = `${timestamp}.${payload.toString("utf8")}`;
  const computed = crypto.createHmac("sha256", secret).update(signedPayload).digest("hex");
  const expected = Buffer.from(expectedSignature, "hex");
  const actual = Buffer.from(computed, "hex");

  if (expected.length !== actual.length || !crypto.timingSafeEqual(expected, actual)) {
    return { ok: false, error: "Stripe signature mismatch." };
  }

  return { ok: true, event: JSON.parse(payload.toString("utf8")) };
}

async function verifyPayPalWebhook(req: express.Request): Promise<{ ok: boolean; event?: any; error?: string }> {
  const webhookId = String(req.headers["paypal-transmission-id"] || "");
  const timestamp = String(req.headers["paypal-transmission-time"] || "");
  const signature = String(req.headers["paypal-transmission-sig"] || "");
  const certUrl = String(req.headers["paypal-cert-url"] || "");
  const eventBody = Buffer.isBuffer(req.body) ? req.body.toString("utf8") : JSON.stringify(req.body ?? {});

  if (!webhookId || !timestamp || !signature || !certUrl) {
    return { ok: false, error: "Missing PayPal webhook headers." };
  }

  const payload = `${webhookId}|${timestamp}|${eventBody}`;
  const computed = crypto.createHmac("sha256", process.env.PAYPAL_WEBHOOK_SECRET || "demo-paypal-secret").update(payload).digest("base64");
  if (!crypto.timingSafeEqual(Buffer.from(computed), Buffer.from(signature))) {
    return { ok: false, error: "PayPal signature mismatch." };
  }

  try {
    return { ok: true, event: JSON.parse(eventBody) };
  } catch {
    return { ok: false, error: "Malformed PayPal webhook payload." };
  }
}

interface FabricRuntimeConnection {
  endpoint: string;
  username: string;
  password: string;
}

interface FabricConnectionStatus {
  connected: boolean;
  strictMode: boolean;
  source: "manual" | "auto-env" | "auto-config" | "none";
  endpoint: string | null;
  username: string | null;
  channels: any;
  error: string | null;
  lastChecked: string | null;
}

type AccountBalances = Record<string, number>;
type PaymentProvider = "stripe" | "paypal" | "bank-link";
type PlanTier = "starter" | "pro" | "enterprise";

// Plan-tier feature matrix: which payment providers are available per subscription tier
const PLAN_PAYMENT_FEATURES: Record<PlanTier, PaymentProvider[]> = {
  starter: ["paypal"],
  pro: ["stripe", "paypal"],
  enterprise: ["stripe", "paypal", "bank-link"],
};

// Subscription plan definitions
const SUBSCRIPTION_PLANS: Record<
  Exclude<PlanTier, "enterprise">,
  { name: string; priceUsd: number; interval: "month"; stripePriceId: string | null; paypalPlanId: string | null }
> = {
  starter: {
    name: "Starter",
    priceUsd: 49,
    interval: "month",
    stripePriceId: process.env.STRIPE_PRICE_STARTER || null,
    paypalPlanId: process.env.PAYPAL_PLAN_STARTER || null,
  },
  pro: {
    name: "Pro",
    priceUsd: 299,
    interval: "month",
    stripePriceId: process.env.STRIPE_PRICE_PRO || null,
    paypalPlanId: process.env.PAYPAL_PLAN_PRO || null,
  },
};

// OAuth configuration - load from environment or use defaults
const OAUTH_CONFIG = {
  stripe: {
    clientId: process.env.STRIPE_OAUTH_CLIENT_ID || "ca_test_stripe_oauth_client_id",
    clientSecret: process.env.STRIPE_OAUTH_CLIENT_SECRET || "secret_test_stripe_oauth_secret",
    redirectUri: `${process.env.OAUTH_REDIRECT_BASE || "http://localhost:3000"}/api/oauth/stripe/callback`,
    authorizationUrl: "https://connect.stripe.com/oauth/authorize",
    tokenUrl: "https://connect.stripe.com/oauth/token",
  },
  paypal: {
    clientId: process.env.PAYPAL_OAUTH_CLIENT_ID || "AZBLp0test_paypal_client_id",
    clientSecret: process.env.PAYPAL_OAUTH_CLIENT_SECRET || "secret_test_paypal_client_secret",
    redirectUri: `${process.env.OAUTH_REDIRECT_BASE || "http://localhost:3000"}/api/oauth/paypal/callback`,
    authorizationUrl: process.env.PAYPAL_SANDBOX ? 
      "https://www.sandbox.paypal.com/oauth2/auth" : 
      "https://www.paypal.com/oauth2/auth",
    tokenUrl: process.env.PAYPAL_SANDBOX ? 
      "https://api.sandbox.paypal.com/v1/oauth2/token" : 
      "https://api.paypal.com/v1/oauth2/token",
  },
  plaid: {
    clientId: process.env.PLAID_CLIENT_ID || "test_plaid_client_id",
    secret: process.env.PLAID_SECRET || "secret_test_plaid_secret",
    publicKey: process.env.PLAID_PUBLIC_KEY || "test_plaid_public_key",
    environment: process.env.PLAID_ENV || "sandbox",
  },
};

function envFlagEnabled(value: string | undefined): boolean {
  if (!value) return false;
  const normalized = value.trim().toLowerCase();
  return normalized === "1" || normalized === "true" || normalized === "yes" || normalized === "on";
}

async function startServer() {
  const app = express();
  const PORT = 3000;
  const fabricStrictMode =
    envFlagEnabled(process.env.FABRIC_STRICT_MODE) ||
    envFlagEnabled(process.env.REQUIRE_FABRIC_AUTOCONNECT) ||
    envFlagEnabled(process.env.KALEIDO_FABRIC_STRICT_MODE);
  let runtimeFabricConnection: FabricRuntimeConnection | null = null;
  let fabricStatus: FabricConnectionStatus = {
    connected: false,
    strictMode: fabricStrictMode,
    source: "none",
    endpoint: null,
    username: null,
    channels: null,
    error: null,
    lastChecked: null,
  };

  app.use((req, _res, next) => {
    const rawCookies = String(req.headers.cookie ?? "");
    const cookies: Record<string, string> = {};
    for (const part of rawCookies.split(";")) {
      const trimmed = part.trim();
      if (!trimmed) continue;
      const idx = trimmed.indexOf("=");
      const key = idx >= 0 ? trimmed.slice(0, idx) : trimmed;
      const value = idx >= 0 ? decodeURIComponent(trimmed.slice(idx + 1)) : "";
      cookies[key] = value;
    }
    (req as any).cookies = cookies;
    next();
  });

  app.use(express.json());

  function normalizeEmail(raw: string | undefined): string | null {
    const value = raw?.trim().toLowerCase();
    if (!value) return null;
    return value;
  }

  function normalizePhone(raw: string | undefined): string | null {
    const value = raw?.trim();
    if (!value) return null;
    return value.replace(/\s+/g, "");
  }

  function parseBalances(value: unknown): AccountBalances {
    try {
      if (!value) return {};
      if (typeof value === "string") return JSON.parse(value) as AccountBalances;
      if (typeof value === "object") return value as AccountBalances;
      return {};
    } catch {
      return {};
    }
  }

  function round(value: number, decimals = 8): number {
    const p = 10 ** decimals;
    return Math.round(value * p) / p;
  }

  function normalizePaymentProvider(raw: unknown): PaymentProvider | null {
    const value = String(raw ?? "").trim().toLowerCase();
    if (value === "stripe" || value === "paypal" || value === "bank-link") {
      return value as PaymentProvider;
    }
    return null;
  }

  function parseJson(value: unknown): Record<string, any> {
    try {
      if (!value) return {};
      if (typeof value === "string") return JSON.parse(value);
      if (typeof value === "object") return value as Record<string, any>;
      return {};
    } catch {
      return {};
    }
  }

  // OAuth helper functions
  function generateOAuthState(): string {
    return crypto.randomBytes(32).toString("hex");
  }

  function getAuthorizedProvidersForPlan(planTier: unknown): PaymentProvider[] {
    const tier = String(planTier ?? "starter").toLowerCase() as PlanTier;
    return PLAN_PAYMENT_FEATURES[tier] || PLAN_PAYMENT_FEATURES.starter;
  }

  function isProviderAllowedForPlan(provider: PaymentProvider, planTier: unknown): boolean {
    return getAuthorizedProvidersForPlan(planTier).includes(provider);
  }

  async function exchangeOAuthCode(
    provider: "stripe" | "paypal",
    code: string
  ): Promise<{ accessToken: string; refreshToken?: string; expiresIn?: number; scope: string }> {
    const config = OAUTH_CONFIG[provider];
    
    try {
      const params = new URLSearchParams({
        code,
        client_id: config.clientId,
        client_secret: config.clientSecret,
        grant_type: "authorization_code",
        redirect_uri: config.redirectUri,
      });

      const response = await fetch(config.tokenUrl, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: params.toString(),
      });

      const data = await response.json() as any;
      if (!response.ok) {
        throw new Error(data?.error_description || data?.error || "OAuth token exchange failed");
      }

      return {
        accessToken: data.access_token,
        refreshToken: data.refresh_token,
        expiresIn: data.expires_in,
        scope: data.scope || "",
      };
    } catch (err: any) {
      throw new Error(`Failed to exchange OAuth code for ${provider}: ${err?.message}`);
    }
  }

  function generateStripeConnectAuthUrl(state: string): string {
    const config = OAUTH_CONFIG.stripe;
    const params = new URLSearchParams({
      client_id: config.clientId,
      state,
      redirect_uri: config.redirectUri,
      response_type: "code",
      scope: "read_write",
      suggested_capabilities: "card_payments,transfers",
    });
    return `${config.authorizationUrl}?${params.toString()}`;
  }

  function generatePayPalAuthUrl(state: string): string {
    const config = OAUTH_CONFIG.paypal;
    const params = new URLSearchParams({
      client_id: config.clientId,
      state,
      redirect_uri: config.redirectUri,
      response_type: "code",
      scope: "https://api.paypal.com/v1/payments/payment/create https://api.paypal.com/v1/vault/credit-card",
    });
    return `${config.authorizationUrl}?${params.toString()}`;
  }

  function generatePlaidLinkToken(userId: string): Promise<string> {
    // For Plaid Link, return the public key and user token info
    // The frontend will initialize Plaid Link SDK with this
    return Promise.resolve(OAUTH_CONFIG.plaid.publicKey || "test_plaid_token");
  }

  function ensureDefaultLinkedAccounts() {
    const existing = queries.linkedAccounts.list.all() as any[];
    if (existing.length > 0) return;

    const seed = [
      {
        id: "acc-prime-01",
        label: "Prime Broker Account",
        provider: "Hyper-Cross Prime",
        balances: { USD: 250000, BTC: 2.4, ETH: 45.2, SOL: 1500 },
      },
      {
        id: "acc-cex-02",
        label: "Exchange Operations",
        provider: "Global CEX",
        balances: { USD: 92000, BTC: 0.85, ETH: 12.6, USDT: 180000 },
      },
    ];

    for (const account of seed) {
      queries.linkedAccounts.create.run(
        account.id,
        account.label,
        account.provider,
        JSON.stringify(account.balances)
      );
    }
  }

  ensureDefaultLinkedAccounts();

  app.post("/api/auth/signup", (req, res) => {
    try {
      const method = req.body?.method === "phone" ? "phone" : "email";
      const email = normalizeEmail(req.body?.emailOrSubAccount);
      const phone = normalizePhone(req.body?.phoneNumber);
      const password = String(req.body?.password || "");

      if (password.length < 8) {
        return res.status(400).json({ error: "Password must be at least 8 characters." });
      }

      if (method === "email") {
        if (!email) return res.status(400).json({ error: "Email is required." });
        const existing = queries.authUser.getByEmail.get(email) as any;
        if (existing) return res.status(409).json({ error: "An account with that email already exists." });

        const id = crypto.randomUUID();
        const orgId = crypto.randomUUID();
        const orgName = `${email.split("@")[0]}'s workspace`;
        queries.authUser.create.run(id, email, null, hashPassword(password));
        queries.organization.create.run(orgId, orgName, id, JSON.stringify({}));
        queries.organizationMember.add.run(crypto.randomUUID(), id, orgId, "OWNER");
        queries.authUser.touchLogin.run(id);

        const sessionId = createSessionToken();
        queries.session.create.run(sessionId, id, orgId, "OWNER", getSessionExpiration().toISOString());
        res.cookie(getSessionCookieName(), sessionId, getSessionCookieOptions());
        return res.status(201).json({ ok: true, user: { id, email, method: "email", organizationId: orgId, role: "OWNER" } });
      }

      if (!phone) return res.status(400).json({ error: "Phone number is required." });
      const existing = queries.authUser.getByPhone.get(phone) as any;
      if (existing) return res.status(409).json({ error: "An account with that phone number already exists." });

      const id = crypto.randomUUID();
      const orgId = crypto.randomUUID();
      const orgName = `${phone} workspace`;
      queries.authUser.create.run(id, null, phone, hashPassword(password));
      queries.organization.create.run(orgId, orgName, id, JSON.stringify({}));
      queries.organizationMember.add.run(crypto.randomUUID(), id, orgId, "OWNER");
      queries.authUser.touchLogin.run(id);

      const sessionId = createSessionToken();
      queries.session.create.run(sessionId, id, orgId, "OWNER", getSessionExpiration().toISOString());
      res.cookie(getSessionCookieName(), sessionId, getSessionCookieOptions());
      return res.status(201).json({ ok: true, user: { id, phone, method: "phone", organizationId: orgId, role: "OWNER" } });
    } catch (error) {
      console.error("Signup error:", error);
      return res.status(500).json({ error: "Unable to create account." });
    }
  });

  app.get("/api/auth/me", requireAuth, (req: AuthenticatedRequest, res) => {
    return res.json({ ok: true, user: req.user });
  });

  app.post("/api/auth/logout", requireAuth, (req: AuthenticatedRequest, res) => {
    const sessionId = (req as any).cookies?.[getSessionCookieName()];
    if (sessionId) queries.session.deleteById.run(sessionId);
    clearSessionCookie(res);
    return res.json({ ok: true, loggedOut: true });
  });

  app.post("/api/auth/signin", (req, res) => {
    try {
      const method = req.body?.method === "phone" ? "phone" : "email";
      const email = normalizeEmail(req.body?.emailOrSubAccount);
      const phone = normalizePhone(req.body?.phoneNumber);
      const password = String(req.body?.password || "");

      if (!password) {
        return res.status(400).json({ error: "Password is required." });
      }

      const user = method === "email"
        ? (email ? (queries.authUser.getByEmail.get(email) as any) : null)
        : (phone ? (queries.authUser.getByPhone.get(phone) as any) : null);

      if (!user) {
        return res.status(401).json({ error: "Invalid credentials." });
      }

      if (!verifyPassword(password, String(user.passwordHash))) {
        return res.status(401).json({ error: "Invalid credentials." });
      }

      const membership = (queries.organizationMember.getByUser.get(user.id) as any[]) ?? [];
      const primaryOrg = membership[0];
      const sessionId = createSessionToken();
      const orgId = primaryOrg?.orgId ?? null;
      const role = isValidRole(primaryOrg?.role) ? primaryOrg.role : "OWNER";

      queries.authUser.touchLogin.run(String(user.id));
      queries.session.create.run(sessionId, user.id, orgId, role, getSessionExpiration().toISOString());
      res.cookie(getSessionCookieName(), sessionId, getSessionCookieOptions());
      return res.json({
        ok: true,
        user: {
          id: user.id,
          email: user.email,
          phone: user.phone,
          method,
          organizationId: orgId,
          role,
        },
      });
    } catch (error) {
      console.error("Signin error:", error);
      return res.status(500).json({ error: "Unable to sign in." });
    }
  });

  app.get("/api/blockchain/status", async (req, res) => {
    try {
      const provider = BlockchainProviderFactory.createFromEnvironment();
      const status = await provider.getStatus();
      return res.json({
        provider: status.provider,
        network: status.network,
        chainId: status.chainId ?? null,
        connected: status.connected,
        rpcHealthy: status.rpcHealthy,
        live: status.live,
        blockNumber: status.blockNumber ?? null,
        error: status.error ?? null,
        lastChecked: status.lastChecked ?? null,
      });
    } catch (error: any) {
      return res.status(200).json({
        provider: "chainstack",
        network: process.env.CHAINSTACK_NETWORK || "ethereum",
        chainId: Number(process.env.CHAINSTACK_CHAIN_ID || 1),
        connected: false,
        rpcHealthy: false,
        live: false,
        blockNumber: null,
        error: error?.message ?? "Chainstack RPC is not configured.",
        lastChecked: new Date().toISOString(),
      });
    }
  });

  // Proxy route for Kaleido REST Gateway
  app.get("/api/kaleido", async (req, res) => {
    try {
      const key = process.env.KALEIDO_API_KEY?.trim();
      const authHeader = key
        ? (key.toLowerCase().startsWith("basic ") ? key : "Basic " + Buffer.from(key).toString("base64"))
        : undefined;
      const restUrl = process.env.KALEIDO_REST_URL;
      const strictLive = envFlagEnabled(process.env.LIVE_FEED_STRICT) || envFlagEnabled(process.env.KALEIDO_LIVE_STRICT);

      let recentBlocks: any[] = [];
      let syncStatus = "Syncing...";
      let latestBlockNumber = 0;
      
      if (restUrl) {
        if (!restUrl.startsWith('http://') && !restUrl.startsWith('https://')) {
          console.error(`Invalid KALEIDO_REST_URL provided: "${restUrl}". It must be a valid URL starting with http:// or https://. Did you accidentally paste the base64 credentials here?`);
          if (strictLive) {
            return res.status(500).json({ error: "Invalid KALEIDO_REST_URL format." });
          }
        } else {
          try {
            // Attempt to fetch from Kaleido JSON-RPC endpoint
            const rpcRes = await fetch(restUrl, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                ...(authHeader ? { 'Authorization': authHeader } : {})
              },
              body: JSON.stringify({
                jsonrpc: "2.0",
                method: "eth_blockNumber",
                params: [],
                id: 1
              })
            });
            
            if (rpcRes.ok) {
              const rpcData = await rpcRes.json();
              if (rpcData.result) {
                const latestBlock = parseInt(rpcData.result, 16);
                latestBlockNumber = latestBlock;
                syncStatus = "Synced";
                
                // Fetch last 5 blocks
                for(let i = 0; i < 5; i++) {
                  const blockRes = await fetch(restUrl, {
                    method: 'POST',
                    headers: {
                      'Content-Type': 'application/json',
                      ...(authHeader ? { 'Authorization': authHeader } : {})
                    },
                    body: JSON.stringify({
                      jsonrpc: "2.0",
                      method: "eth_getBlockByNumber",
                      params: ["0x" + (latestBlock - i).toString(16), false],
                      id: i + 2
                    })
                  });
                  const blockData = await blockRes.json();
                  if (blockData.result) {
                    recentBlocks.push({
                      id: blockData.result.hash ? blockData.result.hash.substring(0, 10) + "..." : `Block ${latestBlock - i}`,
                      timestamp: new Date(parseInt(blockData.result.timestamp, 16) * 1000).toISOString(),
                      transactions: blockData.result.transactions ? blockData.result.transactions.length : 0,
                      status: "Confirmed"
                    });
                  }
                }
              }
            } else {
              console.warn(`Kaleido node returned status ${rpcRes.status}`);
              if (strictLive) {
                return res.status(502).json({ error: `Kaleido node returned HTTP ${rpcRes.status}` });
              }
            }
          } catch (e) {
            console.error("Error calling Kaleido node:", e);
            if (strictLive) {
              return res.status(502).json({ error: "Failed to query Kaleido node." });
            }
          }
        }
      } else {
        console.warn("KALEIDO_REST_URL is not set.");
      }

      // If we couldn't fetch real blocks, use simulated ones
      if (recentBlocks.length === 0) {
        if (strictLive && restUrl) {
          return res.status(502).json({ error: "No live block data returned by configured Kaleido node." });
        }
        recentBlocks = Array.from({ length: 5 }).map((_, i) => ({
          id: `0x${Math.random().toString(16).slice(2, 10)}`,
          timestamp: new Date(Date.now() - i * 15000).toISOString(),
          transactions: Math.floor(Math.random() * 500),
          status: Math.random() > 0.05 ? "Confirmed" : "Pending",
        }));
        syncStatus = Math.random() > 0.1 ? "Synced" : "Syncing...";
      }

      const txCounts = recentBlocks.map((b) => Number(b.transactions || 0));
      const avgTx = txCounts.length ? txCounts.reduce((a, b) => a + b, 0) / txCounts.length : 0;
      const maxTx = txCounts.length ? Math.max(...txCounts, 1) : 1;
      const chaosLevel = ((avgTx / maxTx) * 10).toFixed(2);
      const damping = Math.max(0.1, 10 - Number(chaosLevel)).toFixed(2);

      // Live-derived metrics when available, simulated only as final fallback.
      const data = {
        nodeState: latestBlockNumber > 0 ? String(latestBlockNumber) : (Math.random() * 100).toFixed(2),
        chaosLevel: latestBlockNumber > 0 ? chaosLevel : (Math.random() * 10).toFixed(2),
        damping: latestBlockNumber > 0 ? damping : (Math.random() * 5).toFixed(2),
        syncStatus,
        recentBlocks,
        chartData: Array.from({ length: 20 }).map((_, i) => ({
          time: new Date(Date.now() - (19 - i) * 5000).toLocaleTimeString(),
          stability: 80 + Math.random() * 20,
          chaos: Math.random() * 30,
        }))
      };

      res.json(data);
    } catch (error) {
      console.error("Error fetching Kaleido data:", error);
      res.status(500).json({ error: "Failed to fetch data" });
    }
  });

  // ── Kaleido Hyperledger Fabric proxy routes (mirrors /api/ Vercel functions) ──

  function validateFabricUrl(raw: string): URL | null {
    try {
      const u = new URL(raw);
      if (u.protocol !== "https:" && u.protocol !== "http:") return null;
      return u;
    } catch { return null; }
  }

  function resolveAutoFabricConnection(): (FabricRuntimeConnection & { source: "auto-env" | "auto-config" }) | null {
    const endpointFromConfig = (whiteLabelConfig as any)?.datasources?.fabric?.restGatewayUrl;
    const endpoint =
      process.env.FABRIC_ENDPOINT ||
      process.env.KALEIDO_FABRIC_ENDPOINT ||
      endpointFromConfig;
    const username = process.env.FABRIC_USERNAME || process.env.KALEIDO_FABRIC_USERNAME;
    const password = process.env.FABRIC_PASSWORD || process.env.KALEIDO_FABRIC_PASSWORD;

    if (!endpoint || !username || !password) {
      return null;
    }

    const source =
      process.env.FABRIC_ENDPOINT || process.env.KALEIDO_FABRIC_ENDPOINT
        ? "auto-env"
        : "auto-config";

    return { endpoint: String(endpoint), username: String(username), password: String(password), source };
  }

  function getFabricConnectionFromRequest(body: any): FabricRuntimeConnection | null {
    const endpoint = body?.endpoint?.trim?.();
    const username = body?.username?.trim?.();
    const password = body?.password;

    if (endpoint && username && password) {
      return { endpoint, username, password: String(password) };
    }

    if (runtimeFabricConnection) {
      return runtimeFabricConnection;
    }

    const autoConn = resolveAutoFabricConnection();
    if (autoConn) {
      runtimeFabricConnection = {
        endpoint: autoConn.endpoint,
        username: autoConn.username,
        password: autoConn.password,
      };
      return runtimeFabricConnection;
    }

    return null;
  }

  async function verifyFabricConnection(connection: FabricRuntimeConnection) {
    const url = validateFabricUrl(connection.endpoint);
    if (!url) {
      throw new Error("Invalid Fabric endpoint URL");
    }

    const auth = "Basic " + Buffer.from(`${connection.username}:${connection.password}`).toString("base64");
    const base = url.origin + url.pathname.replace(/\/+$/, "");
    const r = await fetch(`${base}/channels`, {
      headers: { Authorization: auth, "Content-Type": "application/json" },
      signal: AbortSignal.timeout(10000),
    });
    const text = await r.text();
    let data: any;
    try {
      data = JSON.parse(text);
    } catch {
      data = text;
    }

    if (!r.ok) {
      throw new Error(`Node returned HTTP ${r.status}`);
    }

    return data;
  }

  async function setActiveFabricConnection(
    connection: FabricRuntimeConnection,
    source: FabricConnectionStatus["source"],
    channels: any
  ) {
    runtimeFabricConnection = connection;
    const { dataSourceManager } = await import("./src/services/dataSourceManager");
    await dataSourceManager.setFabricConnection(connection.endpoint, connection.username, connection.password);

    fabricStatus = {
      connected: true,
      strictMode: fabricStrictMode,
      source,
      endpoint: connection.endpoint,
      username: connection.username,
      channels,
      error: null,
      lastChecked: new Date().toISOString(),
    };
  }

  async function bootstrapAutoFabricConnection() {
    const autoConnection = resolveAutoFabricConnection();
    if (!autoConnection) {
      const strictError = "[fabric] Strict mode is enabled, but FABRIC_ENDPOINT/FABRIC_USERNAME/FABRIC_PASSWORD are not fully configured.";
      if (fabricStrictMode) {
        throw new Error(strictError);
      }
      console.warn("[fabric] Auto-connect skipped. Set FABRIC_ENDPOINT/FABRIC_USERNAME/FABRIC_PASSWORD to enable zero-touch startup.");
      return;
    }

    try {
      const channels = await verifyFabricConnection(autoConnection);
      await setActiveFabricConnection(autoConnection, autoConnection.source, channels);
      console.log(`[fabric] Auto-connected using ${autoConnection.source} (${autoConnection.endpoint}).`);
    } catch (err: any) {
      fabricStatus = {
        connected: false,
        strictMode: fabricStrictMode,
        source: autoConnection.source,
        endpoint: autoConnection.endpoint,
        username: autoConnection.username,
        channels: null,
        error: err?.message ?? "Auto-connect failed",
        lastChecked: new Date().toISOString(),
      };
      console.error("[fabric] Auto-connect failed:", err?.message ?? err);
      if (fabricStrictMode) {
        throw new Error(err?.message ?? "Auto-connect failed in strict mode");
      }
    }
  }

  function parseArgs(args: any): string[] {
    if (Array.isArray(args)) return args.map(String);
    if (typeof args === "string" && args.trim()) {
      try {
        const p = JSON.parse(args);
        return Array.isArray(p) ? p.map(String) : [String(p)];
      } catch {
        return args.split(",").map((s: string) => s.trim()).filter(Boolean);
      }
    }
    return [];
  }

  app.post("/api/fabric-connect", requireAuth, requirePermission("manage_blockchain"), async (req, res) => {
    const { endpoint, username, password } = req.body ?? {};
    if (!endpoint || !username || !password)
      return res.status(400).json({ error: "endpoint, username, and password are required" });
    const url = validateFabricUrl(endpoint);
    if (!url) return res.status(400).json({ error: "Invalid endpoint URL" });
    const auth = "Basic " + Buffer.from(`${username}:${password}`).toString("base64");
    const base = url.origin + url.pathname.replace(/\/+$/, "");
    try {
      const r = await fetch(`${base}/channels`, {
        headers: { Authorization: auth, "Content-Type": "application/json" },
        signal: AbortSignal.timeout(10000),
      });
      const text = await r.text();
      let data: any;
      try { data = JSON.parse(text); } catch { data = text; }
      if (r.ok) {
        await setActiveFabricConnection({ endpoint: endpoint.trim(), username: username.trim(), password: String(password) }, "manual", data);
      }
      return res.status(r.ok ? 200 : r.status).json(
        r.ok ? { connected: true, channels: data } : { connected: false, error: `Node returned HTTP ${r.status}`, details: data }
      );
    } catch (err: any) {
      return res.status(503).json({ connected: false, error: "Could not reach endpoint: " + (err?.message ?? "unknown") });
    }
  });

  app.post("/api/fabric-query", requireAuth, requirePermission("manage_blockchain"), async (req, res) => {
    const { channel, chaincode, func, args } = req.body ?? {};
    if (!channel || !chaincode || !func)
      return res.status(400).json({ error: "Missing required fields" });
    const connection = getFabricConnectionFromRequest(req.body);
    if (!connection)
      return res.status(400).json({ error: "Fabric is not configured. Set server env vars or connect once from the Fabric page." });
    const { endpoint, username, password } = connection;
    const url = validateFabricUrl(endpoint);
    if (!url) return res.status(400).json({ error: "Invalid endpoint URL" });
    const auth = "Basic " + Buffer.from(`${username}:${password}`).toString("base64");
    const base = url.origin + url.pathname.replace(/\/+$/, "");
    const payload = { headers: { type: "Query", channel, chaincode }, func, args: parseArgs(args) };
    try {
      const r = await fetch(`${base}/query`, {
        method: "POST",
        headers: { Authorization: auth, "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        signal: AbortSignal.timeout(15000),
      });
      const text = await r.text();
      let data: any;
      try { data = JSON.parse(text); } catch { data = text; }
      return res.status(r.status).json(data);
    } catch (err: any) {
      return res.status(503).json({ error: "Could not reach endpoint: " + (err?.message ?? "unknown") });
    }
  });

  app.post("/api/fabric-invoke", requireAuth, requirePermission("deploy_contracts"), async (req, res) => {
    const { channel, chaincode, func, args, signer } = req.body ?? {};
    if (!channel || !chaincode || !func)
      return res.status(400).json({ error: "Missing required fields" });
    const connection = getFabricConnectionFromRequest(req.body);
    if (!connection)
      return res.status(400).json({ error: "Fabric is not configured. Set server env vars or connect once from the Fabric page." });
    const { endpoint, username, password } = connection;
    const url = validateFabricUrl(endpoint);
    if (!url) return res.status(400).json({ error: "Invalid endpoint URL" });
    const auth = "Basic " + Buffer.from(`${username}:${password}`).toString("base64");
    const base = url.origin + url.pathname.replace(/\/+$/, "");
    const payload = {
      headers: { type: "SendTransaction", channel, chaincode, ...(signer ? { signer } : {}) },
      func, args: parseArgs(args),
    };
    try {
      const r = await fetch(`${base}/transactions`, {
        method: "POST",
        headers: { Authorization: auth, "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        signal: AbortSignal.timeout(30000),
      });
      const text = await r.text();
      let data: any;
      try { data = JSON.parse(text); } catch { data = text; }
      return res.status(r.status).json(data);
    } catch (err: any) {
      return res.status(503).json({ error: "Could not reach endpoint: " + (err?.message ?? "unknown") });
    }
  });

  // ── Live Data Routes for Modules ──

  app.post("/api/live/set-fabric-connection", requireAuth, requirePermission("manage_blockchain"), async (req, res) => {
    const { endpoint, username, password } = req.body ?? {};
    if (!endpoint || !username || !password)
      return res.status(400).json({ error: "Missing credentials" });
    try {
      const channels = await verifyFabricConnection({ endpoint, username, password });
      await setActiveFabricConnection({ endpoint, username, password }, "manual", channels);
      res.json({ success: true, channels });
    } catch (err: any) {
      res.status(500).json({ error: err?.message ?? "Failed to set connection" });
    }
  });

  app.get("/api/live/connection-status", (req, res) => {
    res.json(fabricStatus);
  });

  // OAuth endpoints for payment provider authorization

  app.get("/api/oauth/authorize", requireAuth, requirePermission("manage_billing"), (req, res) => {
    const { provider, plan } = req.query;
    const providerStr = String(provider ?? "").toLowerCase() as PaymentProvider;
    const planStr = String(plan ?? "starter");

    // Check if provider is allowed for plan tier
    if (!isProviderAllowedForPlan(providerStr, planStr)) {
      return res.status(403).json({
        error: `${providerStr} is not available for ${planStr} tier`,
        availableProviders: getAuthorizedProvidersForPlan(planStr),
      });
    }

    if (providerStr === "stripe") {
      const state = generateOAuthState();
      // Store state in session/db for verification on callback (in production, use session store)
      res.json({
        authUrl: generateStripeConnectAuthUrl(state),
        state,
        provider: "stripe",
      });
    } else if (providerStr === "paypal") {
      const state = generateOAuthState();
      res.json({
        authUrl: generatePayPalAuthUrl(state),
        state,
        provider: "paypal",
      });
    } else if (providerStr === "bank-link") {
      generatePlaidLinkToken(req.query.userId as string || "user_default").then((token) => {
        res.json({
          provider: "bank-link",
          linkToken: token,
          plaidConfig: {
            clientId: OAUTH_CONFIG.plaid.clientId,
            env: OAUTH_CONFIG.plaid.environment,
          },
        });
      }).catch((err) => {
        res.status(500).json({ error: err?.message || "Failed to generate Plaid token" });
      });
    } else {
      res.status(400).json({
        error: "provider must be one of stripe, paypal, bank-link",
        example: "/api/oauth/authorize?provider=stripe&plan=pro",
      });
    }
  });

  app.post("/api/oauth/stripe/callback", async (req, res) => {
    try {
      const { code, state } = req.body;
      if (!code) {
        return res.status(400).json({ error: "code is required" });
      }

      const tokenData = await exchangeOAuthCode("stripe", code);
      storeEncryptedOAuthToken(
        "stripe",
        tokenData.accessToken,
        tokenData.refreshToken || null,
        tokenData.expiresIn ? new Date(Date.now() + tokenData.expiresIn * 1000).toISOString() : null,
        tokenData.scope,
        "Bearer",
        { state, linkedAt: new Date().toISOString() }
      );

      // Also update paymentConnections to mark as connected
      queries.paymentConnections.upsert.run(
        "stripe",
        "connected",
        code, // Store the authorization code as reference
        JSON.stringify({ oauthTokenId: tokenId, method: "oauth" })
      );

      res.json({
        ok: true,
        provider: "stripe",
        status: "connected",
        message: "Stripe Connect linked successfully",
      });
    } catch (err: any) {
      res.status(500).json({
        ok: false,
        error: err?.message || "Failed to process Stripe callback",
      });
    }
  });

  app.post("/api/oauth/paypal/callback", async (req, res) => {
    try {
      const { code, state } = req.body;
      if (!code) {
        return res.status(400).json({ error: "code is required" });
      }

      const tokenData = await exchangeOAuthCode("paypal", code);
      storeEncryptedOAuthToken(
        "paypal",
        tokenData.accessToken,
        tokenData.refreshToken || null,
        tokenData.expiresIn ? new Date(Date.now() + tokenData.expiresIn * 1000).toISOString() : null,
        tokenData.scope,
        "Bearer",
        { state, linkedAt: new Date().toISOString() }
      );

      // Also update paymentConnections to mark as connected
      queries.paymentConnections.upsert.run(
        "paypal",
        "connected",
        code, // Store the authorization code as reference
        JSON.stringify({ oauthTokenId: tokenId, method: "oauth" })
      );

      res.json({
        ok: true,
        provider: "paypal",
        status: "connected",
        message: "PayPal Partner account linked successfully",
      });
    } catch (err: any) {
      res.status(500).json({
        ok: false,
        error: err?.message || "Failed to process PayPal callback",
      });
    }
  });

  app.post("/api/oauth/plaid/exchange", async (req, res) => {
    try {
      const { publicToken, userId } = req.body;
      if (!publicToken) {
        return res.status(400).json({ error: "publicToken is required" });
      }

      // In production, exchange publicToken for accessToken via Plaid API
      // For now, store the public token reference
      storeEncryptedOAuthToken(
        "bank-link",
        publicToken,
        null,
        null,
        "bank_account_access",
        "Bearer",
        { linkedAt: new Date().toISOString(), userId }
      );

      // Also update paymentConnections to mark as connected
      queries.paymentConnections.upsert.run(
        "bank-link",
        "connected",
        publicToken,
        JSON.stringify({ oauthTokenId: tokenId, method: "plaid_link" })
      );

      res.json({
        ok: true,
        provider: "bank-link",
        status: "connected",
        message: "Bank account linked successfully via Plaid",
      });
    } catch (err: any) {
      res.status(500).json({
        ok: false,
        error: err?.message || "Failed to process Plaid exchange",
      });
    }
  });

  app.post("/api/oauth/revoke", requireAuth, requirePermission("manage_billing"), (req, res) => {
    try {
      const { provider } = req.body;
      const providerStr = normalizePaymentProvider(provider);
      if (!providerStr) {
        return res.status(400).json({ error: "provider must be one of stripe, paypal, bank-link" });
      }

      queries.oauthTokens.delete.run(providerStr);
      queries.paymentConnections.disconnect.run(providerStr);

      res.json({
        ok: true,
        provider: providerStr,
        message: `${providerStr} OAuth connection revoked`,
      });
    } catch (err: any) {
      res.status(500).json({ error: err?.message ?? "Failed to revoke OAuth connection" });
    }
  });

  app.get("/api/payments/connections", requireAuth, requirePermission("manage_billing"), (req, res) => {
    try {
      const plan = (req.query.plan as string) || "starter";
      const allowedProviders = getAuthorizedProvidersForPlan(plan);

      const rows = queries.paymentConnections.list.all() as any[];
      const byProvider = new Map(rows.map((row) => [String(row.provider), row]));
      const providers: PaymentProvider[] = ["stripe", "paypal", "bank-link"];

      const payload = providers
        .filter((p) => allowedProviders.includes(p))
        .map((provider) => {
          const row = byProvider.get(provider);
          return {
            provider,
            status: row?.status ?? "disconnected",
            accountRef: row?.accountRef ?? null,
            metadata: parseJson(row?.metadata),
            linkedAt: row?.linkedAt ?? null,
            updatedAt: row?.updatedAt ?? null,
            allowed: true,
          };
        });

      // Add disallowed providers info (optional)
      const disallowedProviders = providers.filter((p) => !allowedProviders.includes(p));
      for (const provider of disallowedProviders) {
        payload.push({
          provider,
          status: "not-available",
          accountRef: null,
          metadata: { reason: `Not available for ${plan} tier` },
          linkedAt: null,
          updatedAt: null,
          allowed: false,
        });
      }

      res.json({ connections: payload, plan, allowedProviders });
    } catch (err: any) {
      res.status(500).json({ error: err?.message ?? "Failed to fetch payment connections" });
    }
  });

  app.post("/api/payments/connect", requireAuth, requirePermission("manage_billing"), (req, res) => {
    try {
      const plan = (req.body?.plan as string) || "starter";
      const provider = normalizePaymentProvider(req.body?.provider);
      
      if (!provider) {
        return res.status(400).json({ error: "provider must be one of stripe, paypal, bank-link" });
      }

      // Check if provider is allowed for this plan tier
      if (!isProviderAllowedForPlan(provider, plan)) {
        return res.status(403).json({
          error: `${provider} is not available for ${plan} tier`,
          availableProviders: getAuthorizedProvidersForPlan(plan),
        });
      }

      const accountRef = String(req.body?.accountRef ?? "").trim();
      const metadata = typeof req.body?.metadata === "object" && req.body?.metadata
        ? req.body.metadata
        : {};

      if (!accountRef) {
        return res.status(400).json({ error: "accountRef is required" });
      }

      queries.paymentConnections.upsert.run(
        provider,
        "connected",
        accountRef,
        JSON.stringify(metadata),
      );

      const row = queries.paymentConnections.getByProvider.get(provider) as any;
      return res.status(201).json({
        ok: true,
        connection: {
          provider,
          status: row?.status ?? "connected",
          accountRef: row?.accountRef ?? accountRef,
          metadata: parseJson(row?.metadata),
          linkedAt: row?.linkedAt ?? null,
          updatedAt: row?.updatedAt ?? null,
          allowed: true,
        },
      });
    } catch (err: any) {
      res.status(500).json({ error: err?.message ?? "Failed to connect payment provider" });
    }
  });

  app.post("/api/payments/disconnect", requireAuth, requirePermission("manage_billing"), (req, res) => {
    try {
      const provider = normalizePaymentProvider(req.body?.provider);
      if (!provider) {
        return res.status(400).json({ error: "provider must be one of stripe, paypal, bank-link" });
      }

      queries.paymentConnections.disconnect.run(provider);
      const row = queries.paymentConnections.getByProvider.get(provider) as any;
      return res.json({
        ok: true,
        connection: {
          provider,
          status: row?.status ?? "disconnected",
          accountRef: null,
          metadata: {},
          linkedAt: null,
          updatedAt: row?.updatedAt ?? null,
          allowed: true,
        },
      });
    } catch (err: any) {
      res.status(500).json({ error: err?.message ?? "Failed to disconnect payment provider" });
    }
  });

  app.get("/api/live/linked-accounts", requireAuth, requirePermission("manage_assets"), (req, res) => {
    try {
      const accounts = (queries.linkedAccounts.list.all() as any[]).map((row) => {
        const balances = parseBalances(row.balances);
        const totalUsd = Object.entries(balances).reduce((sum, [asset, amount]) => {
          if (asset === "USD" || asset === "USDT") return sum + Number(amount || 0);
          return sum;
        }, 0);

        return {
          id: row.id,
          label: row.label,
          provider: row.provider,
          balances,
          totalUsd: round(totalUsd, 2),
          updatedAt: row.updatedAt,
        };
      });

      res.json(accounts);
    } catch (err: any) {
      res.status(500).json({ error: err?.message ?? "Failed to fetch linked accounts" });
    }
  });

  app.get("/api/live/trades", requireAuth, requirePermission("manage_assets"), (req, res) => {
    try {
      const rawLimit = Number(req.query.limit ?? 20);
      const limit = Number.isFinite(rawLimit) ? Math.max(1, Math.min(100, rawLimit)) : 20;
      const trades = queries.trades.listRecent.all(limit);
      res.json(trades);
    } catch (err: any) {
      res.status(500).json({ error: err?.message ?? "Failed to fetch trades" });
    }
  });

  app.post("/api/live/execute-trade", requireAuth, requirePermission("execute_permitted_trading_operations"), (req, res) => {
    try {
      const accountId = String(req.body?.accountId ?? "").trim();
      const instrument = String(req.body?.instrument ?? "").trim().toUpperCase();
      const side = String(req.body?.side ?? "").trim().toUpperCase();
      const quantity = Number(req.body?.quantity);
      const price = Number(req.body?.price);

      if (!accountId || !instrument || !["BUY", "SELL"].includes(side)) {
        return res.status(400).json({ error: "accountId, instrument, and side (BUY/SELL) are required." });
      }
      if (!Number.isFinite(quantity) || quantity <= 0) {
        return res.status(400).json({ error: "Quantity must be a positive number." });
      }
      if (!Number.isFinite(price) || price <= 0) {
        return res.status(400).json({ error: "Price must be a positive number." });
      }

      const account = queries.linkedAccounts.getById.get(accountId) as any;
      if (!account) return res.status(404).json({ error: "Linked account not found." });

      const [baseRaw, quoteRaw] = instrument.split("-");
      const base = (baseRaw || "").trim();
      const quote = (quoteRaw || "USD").trim() || "USD";
      if (!base) return res.status(400).json({ error: "Instrument must be formatted like BTC-USD." });

      const balances = parseBalances(account.balances);
      const notional = round(quantity * price, 2);

      if (side === "BUY") {
        const quoteAvailable = Number(balances[quote] ?? 0);
        if (quoteAvailable < notional) {
          return res.status(400).json({ error: `Insufficient ${quote} balance.` });
        }
        balances[quote] = round(quoteAvailable - notional, 2);
        balances[base] = round(Number(balances[base] ?? 0) + quantity, 8);
      } else {
        const baseAvailable = Number(balances[base] ?? 0);
        if (baseAvailable < quantity) {
          return res.status(400).json({ error: `Insufficient ${base} balance.` });
        }
        balances[base] = round(baseAvailable - quantity, 8);
        balances[quote] = round(Number(balances[quote] ?? 0) + notional, 2);
      }

      queries.linkedAccounts.updateBalances.run(JSON.stringify(balances), accountId);

      const tradeId = crypto.randomUUID();
      queries.trades.create.run(tradeId, accountId, instrument, side, quantity, price, notional, "FILLED");

      const updated = queries.linkedAccounts.getById.get(accountId) as any;
      res.status(201).json({
        ok: true,
        trade: {
          id: tradeId,
          accountId,
          instrument,
          side,
          quantity,
          price,
          notional,
          status: "FILLED",
        },
        account: {
          id: updated.id,
          label: updated.label,
          provider: updated.provider,
          balances: parseBalances(updated.balances),
          updatedAt: updated.updatedAt,
        },
      });
    } catch (err: any) {
      res.status(500).json({ error: err?.message ?? "Failed to execute trade" });
    }
  });

  app.get("/api/live/assets", requireAuth, requirePermission("manage_assets"), async (req, res) => {
    try {
      const { dataSourceManager } = await import("./src/services/dataSourceManager");
      const channel = (req.query.channel as string) ?? "default-channel";
      const assets = await dataSourceManager.getAssets(channel);
      res.json(assets);
    } catch (err: any) {
      res.status(500).json({ error: err?.message ?? "Failed to fetch assets" });
    }
  });

  app.get("/api/live/assets/:symbol", requireAuth, requirePermission("manage_assets"), async (req, res) => {
    try {
      const { dataSourceManager } = await import("./src/services/dataSourceManager");
      const channel = (req.query.channel as string) ?? "default-channel";
      const asset = await dataSourceManager.getAssetBySymbol(req.params.symbol, channel);
      res.json(asset);
    } catch (err: any) {
      res.status(500).json({ error: err?.message ?? "Failed to fetch asset" });
    }
  });

  app.post("/api/live/assets/:symbol/transfer", requireAuth, requirePermission("transfer_assets"), async (req, res) => {
    try {
      const { symbol } = req.params;
      const { to, amount, channel, chaincode } = req.body ?? {};

      if (!to || !amount) {
        return res.status(400).json({ error: "Recipient (to) and amount are required." });
      }
      if (isNaN(Number(amount)) || Number(amount) <= 0) {
        return res.status(400).json({ error: "Amount must be a positive number." });
      }

      const ch = String(channel || "default-channel");
      const cc = String(chaincode || "assets");

      // If Fabric is connected, invoke the transfer transaction
      if (runtimeFabricConnection) {
        const { endpoint, username, password } = runtimeFabricConnection;
        const url = validateFabricUrl(endpoint);
        if (url) {
          const auth = "Basic " + Buffer.from(`${username}:${password}`).toString("base64");
          const base = url.origin + url.pathname.replace(/\/+$/, "");
          const payload = {
            headers: { type: "SendTransaction", channel: ch, chaincode: cc },
            func: "Transfer",
            args: [symbol.toUpperCase(), String(to), String(amount)],
          };
          const r = await fetch(`${base}/transactions`, {
            method: "POST",
            headers: { Authorization: auth, "Content-Type": "application/json" },
            body: JSON.stringify(payload),
            signal: AbortSignal.timeout(30000),
          });
          const text = await r.text();
          let data: any;
          try { data = JSON.parse(text); } catch { data = { raw: text }; }
          return res.status(r.status).json({ ok: r.ok, symbol, to, amount, fabricResult: data });
        }
      }

      // Fabric not connected: simulate success
      return res.json({
        ok: true,
        simulated: true,
        symbol,
        to,
        amount,
        message: `Simulated transfer of ${amount} ${symbol.toUpperCase()} to ${to}`,
      });
    } catch (err: any) {
      res.status(500).json({ error: err?.message ?? "Transfer failed" });
    }
  });

  app.post("/api/live/assets/:symbol/burn", requireAuth, requirePermission("manage_assets"), async (req, res) => {
    try {
      const { symbol } = req.params;
      const { amount, channel, chaincode } = req.body ?? {};

      if (!amount) {
        return res.status(400).json({ error: "Amount is required." });
      }
      if (isNaN(Number(amount)) || Number(amount) <= 0) {
        return res.status(400).json({ error: "Amount must be a positive number." });
      }

      const ch = String(channel || "default-channel");
      const cc = String(chaincode || "assets");

      if (runtimeFabricConnection) {
        const { endpoint, username, password } = runtimeFabricConnection;
        const url = validateFabricUrl(endpoint);
        if (url) {
          const auth = "Basic " + Buffer.from(`${username}:${password}`).toString("base64");
          const base = url.origin + url.pathname.replace(/\/+$/, "");
          const payload = {
            headers: { type: "SendTransaction", channel: ch, chaincode: cc },
            func: "Burn",
            args: [symbol.toUpperCase(), String(amount)],
          };
          const r = await fetch(`${base}/transactions`, {
            method: "POST",
            headers: { Authorization: auth, "Content-Type": "application/json" },
            body: JSON.stringify(payload),
            signal: AbortSignal.timeout(30000),
          });
          const text = await r.text();
          let data: any;
          try { data = JSON.parse(text); } catch { data = { raw: text }; }
          return res.status(r.status).json({ ok: r.ok, symbol, amount, fabricResult: data });
        }
      }

      // Fabric not connected: simulate success  
      return res.json({
        ok: true,
        simulated: true,
        symbol,
        amount,
        message: `Simulated burn of ${amount} ${symbol.toUpperCase()} from supply`,
      });
    } catch (err: any) {
      res.status(500).json({ error: err?.message ?? "Burn failed" });
    }
  });

  app.post("/api/live/assets/:symbol/sync", requireAuth, requirePermission("manage_assets"), async (req, res) => {
    try {
      const { symbol } = req.params;
      const { channel, chaincode } = req.body ?? {};
      const ch = String(channel || "default-channel");
      const cc = String(chaincode || "assets");

      if (runtimeFabricConnection) {
        const { endpoint, username, password } = runtimeFabricConnection;
        const url = validateFabricUrl(endpoint);
        if (url) {
          const auth = "Basic " + Buffer.from(`${username}:${password}`).toString("base64");
          const base = url.origin + url.pathname.replace(/\/+$/, "");
          const payload = {
            headers: { type: "Query", channel: ch, chaincode: cc },
            func: "GetAsset",
            args: [symbol.toUpperCase()],
          };
          const r = await fetch(`${base}/query`, {
            method: "POST",
            headers: { Authorization: auth, "Content-Type": "application/json" },
            body: JSON.stringify(payload),
            signal: AbortSignal.timeout(15000),
          });
          const text = await r.text();
          let data: any;
          try { data = JSON.parse(text); } catch { data = { raw: text }; }
          return res.status(r.status).json({ ok: r.ok, symbol, asset: data });
        }
      }

      // Fabric not connected: return simulated refresh confirmation
      return res.json({
        ok: true,
        simulated: true,
        symbol,
        message: `Asset ${symbol.toUpperCase()} state refreshed from chain`,
        syncedAt: new Date().toISOString(),
      });
    } catch (err: any) {
      res.status(500).json({ error: err?.message ?? "Sync failed" });
    }
  });

  app.get("/api/live/market-prices", async (req, res) => {
    try {
      const { dataSourceManager } = await import("./src/services/dataSourceManager");
      const symbols = (req.query.symbols as string)?.split(",") ?? [];
      const prices = await dataSourceManager.getMarketPrices(symbols);
      res.json(prices);
    } catch (err: any) {
      res.status(500).json({ error: err?.message ?? "Failed to fetch prices" });
    }
  });

  app.get("/api/live/orderbook/:instrument", async (req, res) => {
    try {
      const { dataSourceManager } = await import("./src/services/dataSourceManager");
      const orderbook = await dataSourceManager.getLiveOrderBook(req.params.instrument);
      res.json(orderbook);
    } catch (err: any) {
      res.status(500).json({ error: err?.message ?? "Failed to fetch orderbook" });
    }
  });

  app.get("/api/live/rwa", async (req, res) => {
    try {
      const { dataSourceManager } = await import("./src/services/dataSourceManager");
      const channel = (req.query.channel as string) ?? "rwa-channel";
      const rwas = await dataSourceManager.getRWAssets(channel);
      res.json(rwas);
    } catch (err: any) {
      res.status(500).json({ error: err?.message ?? "Failed to fetch RWAs" });
    }
  });

  app.get("/api/live/nft", async (req, res) => {
    try {
      const { dataSourceManager } = await import("./src/services/dataSourceManager");
      const channel = (req.query.channel as string) ?? "nft-channel";
      const nfts = await dataSourceManager.getNFTs(channel);
      res.json(nfts);
    } catch (err: any) {
      res.status(500).json({ error: err?.message ?? "Failed to fetch NFTs" });
    }
  });

  app.get("/api/live/sports-events", async (req, res) => {
    try {
      const { dataSourceManager } = await import("./src/services/dataSourceManager");
      const events = await dataSourceManager.getLiveSportsEvents();
      res.json(events);
    } catch (err: any) {
      res.status(500).json({ error: err?.message ?? "Failed to fetch sports events" });
    }
  });

  app.get("/api/live/mining-stats", async (req, res) => {
    try {
      const { dataSourceManager } = await import("./src/services/dataSourceManager");
      const stats = await dataSourceManager.getMiningPoolStats();
      res.json(stats);
    } catch (err: any) {
      res.status(500).json({ error: err?.message ?? "Failed to fetch mining stats" });
    }
  });

  await bootstrapAutoFabricConnection();

  // ─── Stripe ────────────────────────────────────────────────────────────────

  const stripeSecretKey = process.env.STRIPE_SECRET_KEY || null;

  async function stripeRequest(
    method: string,
    path: string,
    body?: Record<string, string>
  ): Promise<any> {
    if (!stripeSecretKey) throw new Error("STRIPE_SECRET_KEY is not configured.");
    const url = `https://api.stripe.com/v1${path}`;
    const opts: RequestInit = {
      method,
      headers: {
        Authorization: `Bearer ${stripeSecretKey}`,
        "Content-Type": "application/x-www-form-urlencoded",
      },
    };
    if (body) opts.body = new URLSearchParams(body).toString();
    const res = await fetch(url, opts);
    const data = await res.json() as any;
    if (!res.ok) throw new Error(data?.error?.message || `Stripe API error (${res.status})`);
    return data;
  }

  async function stripeCreateCustomer(email: string): Promise<string> {
    const cust = await stripeRequest("POST", "/customers", { email, description: "HyperCross Nexus subscriber" });
    return cust.id as string;
  }

  async function stripeCreateCheckoutSession(
    plan: Exclude<PlanTier, "enterprise">,
    email: string,
    stripeCustomerId: string,
    successUrl: string,
    cancelUrl: string
  ): Promise<{ id: string; url: string }> {
    const planDef = SUBSCRIPTION_PLANS[plan];
    if (!planDef.stripePriceId) {
      // Create a one-time price on-the-fly (sandbox / no pre-created price IDs)
      const price = await stripeRequest("POST", "/prices", {
        currency: "usd",
        unit_amount: String(planDef.priceUsd * 100),
        "recurring[interval]": planDef.interval,
        "product_data[name]": `HyperCross Nexus — ${planDef.name}`,
      });
      planDef.stripePriceId = price.id as string;
    }

    const session = await stripeRequest("POST", "/checkout/sessions", {
      mode: "subscription",
      customer: stripeCustomerId,
      "line_items[0][price]": planDef.stripePriceId,
      "line_items[0][quantity]": "1",
      success_url: successUrl,
      cancel_url: cancelUrl,
      "subscription_data[metadata][plan_tier]": plan,
      "metadata[plan_tier]": plan,
      "metadata[email]": email,
    });
    return { id: session.id as string, url: session.url as string };
  }

  async function stripeRetrieveSession(sessionId: string): Promise<any> {
    return stripeRequest("GET", `/checkout/sessions/${sessionId}`);
  }

  async function stripeCancelSubscription(externalId: string): Promise<void> {
    await stripeRequest("DELETE", `/subscriptions/${externalId}`);
  }

  // ─── PayPal ────────────────────────────────────────────────────────────────

  const paypalClientId = process.env.PAYPAL_CLIENT_ID || process.env.PAYPAL_OAUTH_CLIENT_ID || null;
  const paypalClientSecret = process.env.PAYPAL_CLIENT_SECRET || process.env.PAYPAL_OAUTH_CLIENT_SECRET || null;
  const paypalBase = process.env.PAYPAL_SANDBOX === "false"
    ? "https://api-m.paypal.com"
    : "https://api-m.sandbox.paypal.com";

  async function paypalGetAccessToken(): Promise<string> {
    if (!paypalClientId || !paypalClientSecret) throw new Error("PayPal credentials are not configured.");
    const res = await fetch(`${paypalBase}/v1/oauth2/token`, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        Authorization: `Basic ${Buffer.from(`${paypalClientId}:${paypalClientSecret}`).toString("base64")}`,
      },
      body: "grant_type=client_credentials",
    });
    const data = await res.json() as any;
    if (!res.ok) throw new Error(data?.error_description || "PayPal auth failed");
    return data.access_token as string;
  }

  async function paypalRequest(method: string, path: string, body?: object): Promise<any> {
    const token = await paypalGetAccessToken();
    const res = await fetch(`${paypalBase}${path}`, {
      method,
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: body ? JSON.stringify(body) : undefined,
    });
    const data = await res.json() as any;
    if (!res.ok) throw new Error(data?.message || data?.error_description || `PayPal error (${res.status})`);
    return data;
  }

  async function paypalCreateOrder(
    plan: Exclude<PlanTier, "enterprise">,
    email: string,
    returnUrl: string,
    cancelUrl: string
  ): Promise<{ id: string; approvalUrl: string }> {
    const planDef = SUBSCRIPTION_PLANS[plan];
    const order = await paypalRequest("POST", "/v2/checkout/orders", {
      intent: "CAPTURE",
      purchase_units: [
        {
          amount: { currency_code: "USD", value: String(planDef.priceUsd) },
          description: `HyperCross Nexus — ${planDef.name} (Monthly)`,
          custom_id: `plan:${plan}:email:${email}`,
        },
      ],
      application_context: {
        return_url: returnUrl,
        cancel_url: cancelUrl,
        brand_name: "HyperCross Nexus",
        user_action: "PAY_NOW",
      },
    });

    const approvalLink = (order.links as any[]).find((l: any) => l.rel === "approve");
    return { id: order.id as string, approvalUrl: approvalLink?.href as string };
  }

  async function paypalCaptureOrder(orderId: string): Promise<any> {
    return paypalRequest("POST", `/v2/checkout/orders/${orderId}/capture`);
  }

  // ─── Checkout & Subscription Routes ────────────────────────────────────────

  // Create Stripe or PayPal checkout session
  app.post("/api/checkout/session", async (req, res) => {
    try {
      const provider = String(req.body?.provider ?? "").toLowerCase();
      const plan = String(req.body?.plan ?? "").toLowerCase() as PlanTier;
      const email = normalizeEmail(req.body?.email);
      const baseUrl = `${process.env.OAUTH_REDIRECT_BASE || "http://localhost:3000"}`;

      if (!email) return res.status(400).json({ error: "email is required" });
      if (plan === "enterprise") {
        return res.status(400).json({ error: "Enterprise plan requires contacting sales." });
      }
      if (plan !== "starter" && plan !== "pro") {
        return res.status(400).json({ error: "plan must be starter, pro, or enterprise" });
      }

      // Ensure customer record exists
      let customer = queries.customers.getByEmail.get(email) as any;
      if (!customer) {
        const custId = crypto.randomUUID();
        queries.customers.upsert.run(custId, email, plan);
        customer = queries.customers.getByEmail.get(email) as any;
      }

      if (provider === "stripe") {
        // Get or create Stripe customer
        let stripeCustomerId = customer?.stripeCustomerId as string | null;
        if (!stripeCustomerId) {
          stripeCustomerId = await stripeCreateCustomer(email);
          queries.customers.setStripeId.run(stripeCustomerId, email);
        }

        const successUrl = `${baseUrl}/?checkout=stripe-success&session_id={CHECKOUT_SESSION_ID}&plan=${plan}`;
        const cancelUrl = `${baseUrl}/?checkout=canceled&plan=${plan}`;
        const session = await stripeCreateCheckoutSession(
          plan as Exclude<PlanTier, "enterprise">,
          email,
          stripeCustomerId,
          successUrl,
          cancelUrl
        );

        return res.json({ provider: "stripe", sessionId: session.id, url: session.url });

      } else if (provider === "paypal") {
        const returnUrl = `${baseUrl}/?checkout=paypal-return&plan=${plan}&email=${encodeURIComponent(email)}`;
        const cancelUrl = `${baseUrl}/?checkout=canceled&plan=${plan}`;
        const order = await paypalCreateOrder(
          plan as Exclude<PlanTier, "enterprise">,
          email,
          returnUrl,
          cancelUrl
        );

        return res.json({ provider: "paypal", orderId: order.id, url: order.approvalUrl });

      } else {
        return res.status(400).json({ error: "provider must be stripe or paypal" });
      }
    } catch (err: any) {
      console.error("[checkout/session]", err?.message);
      return res.status(500).json({ error: err?.message || "Failed to create checkout session" });
    }
  });

  // Confirm Stripe checkout (called after user returns from Stripe with session_id)
  app.post("/api/checkout/stripe/confirm", async (req, res) => {
    try {
      const sessionId = String(req.body?.session_id ?? "").trim();
      const email = normalizeEmail(req.body?.email);

      if (!sessionId) return res.status(400).json({ error: "session_id is required" });
      if (!email) return res.status(400).json({ error: "email is required" });

      const session = await stripeRetrieveSession(sessionId);
      if (session.payment_status !== "paid" && session.status !== "complete") {
        return res.status(402).json({ error: "Payment not yet completed.", sessionStatus: session.status });
      }

      const plan = (session.metadata?.plan_tier || "starter") as PlanTier;
      const stripeSubscriptionId = session.subscription as string | null;

      // Upsert customer record
      let customer = queries.customers.getByEmail.get(email) as any;
      if (!customer) {
        const custId = crypto.randomUUID();
        queries.customers.upsert.run(custId, email, plan);
        customer = queries.customers.getByEmail.get(email) as any;
      } else {
        queries.customers.setPlan.run(plan, email);
      }
      if (session.customer && !customer?.stripeCustomerId) {
        queries.customers.setStripeId.run(session.customer as string, email);
      }

      // Calculate billing period (monthly)
      const now = new Date();
      const periodEnd = new Date(now);
      periodEnd.setMonth(periodEnd.getMonth() + 1);

      const subId = crypto.randomUUID();
      queries.subscriptions.upsertByEmail.run(
        subId,
        customer.id,
        email,
        "stripe",
        stripeSubscriptionId || sessionId,
        plan,
        "active",
        now.toISOString(),
        periodEnd.toISOString(),
        JSON.stringify({ stripeSessionId: sessionId, stripeSubscriptionId })
      );

      const subscription = queries.subscriptions.getByEmail.get(email) as any;
      return res.json({ ok: true, plan, subscription });
    } catch (err: any) {
      console.error("[checkout/stripe/confirm]", err?.message);
      return res.status(500).json({ error: err?.message || "Failed to confirm Stripe checkout" });
    }
  });

  // Capture PayPal order (called after user returns from PayPal approval)
  app.post("/api/checkout/paypal/capture", async (req, res) => {
    try {
      const orderId = String(req.body?.order_id ?? "").trim();
      const plan = String(req.body?.plan ?? "starter") as PlanTier;
      const email = normalizeEmail(req.body?.email);

      if (!orderId) return res.status(400).json({ error: "order_id is required" });
      if (!email) return res.status(400).json({ error: "email is required" });

      const captureResult = await paypalCaptureOrder(orderId);
      const captureStatus = captureResult?.status as string;

      if (captureStatus !== "COMPLETED") {
        return res.status(402).json({ error: "Payment not completed.", captureStatus });
      }

      const payerId = captureResult?.payer?.payer_id as string | null;

      // Upsert customer record
      let customer = queries.customers.getByEmail.get(email) as any;
      if (!customer) {
        const custId = crypto.randomUUID();
        queries.customers.upsert.run(custId, email, plan);
        customer = queries.customers.getByEmail.get(email) as any;
      } else {
        queries.customers.setPlan.run(plan, email);
      }
      if (payerId && !customer?.paypalPayerId) {
        queries.customers.setPayPalId.run(payerId, email);
      }

      // Calculate billing period (monthly)
      const now = new Date();
      const periodEnd = new Date(now);
      periodEnd.setMonth(periodEnd.getMonth() + 1);

      const subId = crypto.randomUUID();
      queries.subscriptions.upsertByEmail.run(
        subId,
        customer.id,
        email,
        "paypal",
        orderId,
        plan,
        "active",
        now.toISOString(),
        periodEnd.toISOString(),
        JSON.stringify({ orderId, captureResult })
      );

      const subscription = queries.subscriptions.getByEmail.get(email) as any;
      return res.json({ ok: true, plan, subscription });
    } catch (err: any) {
      console.error("[checkout/paypal/capture]", err?.message);
      return res.status(500).json({ error: err?.message || "Failed to capture PayPal order" });
    }
  });

  // Get current subscription for an email
  app.get("/api/subscription", (req, res) => {
    try {
      const email = normalizeEmail(req.query.email as string | undefined);
      if (!email) return res.status(400).json({ error: "email is required" });

      const customer = queries.customers.getByEmail.get(email) as any;
      const subscription = queries.subscriptions.getByEmail.get(email) as any;

      return res.json({
        customer: customer
          ? { email: customer.email, planTier: customer.planTier, createdAt: customer.createdAt }
          : null,
        subscription: subscription
          ? {
              id: subscription.id,
              provider: subscription.provider,
              planTier: subscription.planTier,
              status: subscription.status,
              currentPeriodStart: subscription.currentPeriodStart,
              currentPeriodEnd: subscription.currentPeriodEnd,
              canceledAt: subscription.canceledAt,
              createdAt: subscription.createdAt,
            }
          : null,
      });
    } catch (err: any) {
      return res.status(500).json({ error: err?.message || "Failed to fetch subscription" });
    }
  });

  // Cancel active subscription
  app.post("/api/subscription/cancel", async (req, res) => {
    try {
      const email = normalizeEmail(req.body?.email);
      if (!email) return res.status(400).json({ error: "email is required" });

      const subscription = queries.subscriptions.getByEmail.get(email) as any;
      if (!subscription || subscription.status !== "active") {
        return res.status(404).json({ error: "No active subscription found." });
      }

      // Cancel at payment provider
      try {
        if (subscription.provider === "stripe" && subscription.externalId?.startsWith("sub_")) {
          await stripeCancelSubscription(subscription.externalId);
        }
        // PayPal subscription cancellation would go here (not needed for one-time orders)
      } catch (providerErr: any) {
        console.warn("[subscription/cancel] Provider cancellation failed:", providerErr?.message);
        // Still cancel locally even if provider fails
      }

      queries.subscriptions.cancel.run(email);
      queries.customers.setPlan.run("starter", email);

      return res.json({ ok: true, message: "Subscription canceled." });
    } catch (err: any) {
      return res.status(500).json({ error: err?.message || "Failed to cancel subscription" });
    }
  });

  // Stripe webhook handler
  app.post("/api/webhooks/stripe", express.raw({ type: "application/json" }), (req, res) => {
    try {
      const payload = Buffer.isBuffer(req.body) ? req.body : Buffer.from(JSON.stringify(req.body ?? {}));
      const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
      const signature = req.headers["stripe-signature"] as string | undefined;
      const verification = requireVerifiedStripeSignature(payload, signature, webhookSecret);
      if (!verification.ok) {
        return res.status(400).json({ error: verification.error ?? "Invalid signature" });
      }
      const event = verification.event ?? JSON.parse(payload.toString("utf8"));
      const eventId = getWebhookEventId(event);
      if (checkDuplicateWebhook("stripe", eventId)) {
        return res.status(409).json({ error: "Duplicate Stripe webhook event." });
      }

      if (event.type === "checkout.session.completed") {
        const session = event.data.object;
        const email = session.metadata?.email;
        const plan = session.metadata?.plan_tier || "starter";
        if (email) {
          let customer = queries.customers.getByEmail.get(email) as any;
          if (!customer) {
            const custId = crypto.randomUUID();
            queries.customers.upsert.run(custId, email, plan);
            customer = queries.customers.getByEmail.get(email) as any;
          }
          const now = new Date().toISOString();
          const periodEnd = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();
          queries.subscriptions.upsertByEmail.run(
            crypto.randomUUID(), customer.id, email, "stripe",
            session.subscription || session.id, plan, "active", now, periodEnd,
            JSON.stringify({ webhookEvent: event.type })
          );
        }
      }

      if (event.type === "customer.subscription.deleted" || event.type === "customer.subscription.updated") {
        const sub = event.data.object;
        const status = sub.status === "active" ? "active" : "canceled";
        queries.subscriptions.updateStatus.run(status, sub.id);
      }

      return res.json({ received: true });
    } catch (err: any) {
      console.error("[webhooks/stripe]", err?.message);
      return res.status(400).json({ error: "Webhook handling failed" });
    }
  });

  // PayPal webhook handler
  app.post("/api/webhooks/paypal", express.raw({ type: "application/json" }), async (req, res) => {
    try {
      const rawBody = Buffer.isBuffer(req.body) ? req.body : Buffer.from(JSON.stringify(req.body ?? {}));
      const verification = await verifyPayPalWebhook({ ...req, body: rawBody } as any);
      if (!verification.ok) {
        return res.status(400).json({ error: verification.error ?? "Invalid PayPal signature" });
      }
      const event = verification.event ?? JSON.parse(rawBody.toString("utf8"));
      const eventId = getWebhookEventId(event);
      if (checkDuplicateWebhook("paypal", eventId)) {
        return res.status(409).json({ error: "Duplicate PayPal webhook event." });
      }
      if (event?.event_type === "PAYMENT.CAPTURE.COMPLETED") {
        const customId: string = event?.resource?.custom_id || "";
        const match = customId.match(/plan:(\w+):email:(.+)/);
        if (match) {
          const plan = match[1] as PlanTier;
          const email = match[2];
          let customer = queries.customers.getByEmail.get(email) as any;
          if (!customer) {
            const custId = crypto.randomUUID();
            queries.customers.upsert.run(custId, email, plan);
            customer = queries.customers.getByEmail.get(email) as any;
          }
          const now = new Date().toISOString();
          const periodEnd = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();
          queries.subscriptions.upsertByEmail.run(
            crypto.randomUUID(), customer.id, email, "paypal",
            event?.resource?.id || event?.id, plan, "active", now, periodEnd,
            JSON.stringify({ webhookEvent: event.event_type })
          );
        }
      }
      return res.json({ received: true });
    } catch (err: any) {
      console.error("[webhooks/paypal]", err?.message);
      return res.status(400).json({ error: "Webhook handling failed" });
    }
  });

  await bootstrapAutoFabricConnection();

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
    if (fabricStrictMode) {
      console.log("[fabric] Strict startup mode enabled.");
    }
  });
}

startServer().catch((err) => {
  console.error("Fatal startup error:", err);
  process.exit(1);
});
