import React, { useEffect, useState } from "react";
import { 
  Activity, 
  Box, 
  LayoutDashboard, 
  Settings, 
  Wallet,
  Zap,
  QrCode,
  Mail,
  Smartphone,
  Lock,
  ArrowRight,
  MonitorSmartphone,
  ShieldCheck
} from "lucide-react";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer 
} from "recharts";

import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

interface KaleidoData {
  nodeState: string;
  chaosLevel: string;
  damping: string;
  syncStatus: string;
  recentBlocks: Array<{
    id: string;
    timestamp: string;
    transactions: number;
    status: string;
  }>;
  chartData: Array<{
    time: string;
    stability: number;
    chaos: number;
  }>;
}

export default function App() {
  const [data, setData] = useState<KaleidoData | null>(null);
  const [loading, setLoading] = useState(true);
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch("/api/kaleido");
        if (response.ok) {
          const result = await response.json();
          setData(result);
        }
      } catch (error) {
        console.error("Failed to fetch data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
    const interval = setInterval(fetchData, 5000); // Poll every 5 seconds
    return () => clearInterval(interval);
  }, []);

  if (!isLoggedIn) {
    return <LoginScreen onLogin={() => setIsLoggedIn(true)} data={data} />;
  }

  return (
    <div className="flex h-screen w-full overflow-hidden bg-transparent text-foreground">
      {/* Sidebar */}
      <aside className="w-64 flex-shrink-0 border-r border-white/10 glass-panel flex flex-col z-10">
        <div className="p-6 flex items-center gap-3 border-b border-white/10">
          <div className="h-8 w-8 rounded-full bg-gradient-to-br from-[#1500ff] to-[#c300ff] flex items-center justify-center shadow-[0_0_15px_rgba(195,0,255,0.5)]">
            <Zap className="h-4 w-4 text-white" />
          </div>
          <h1 className="font-bold text-xl tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white to-white/60">
            Hyper-Cross Nexus
          </h1>
        </div>
        <nav className="flex-1 p-4 space-y-2">
          <NavItem icon={<LayoutDashboard size={18} />} label="Overview" active />
          <NavItem icon={<Box size={18} />} label="Nodes" />
          <NavItem icon={<Activity size={18} />} label="Stability Monitor" />
          <NavItem icon={<Settings size={18} />} label="Settings" />
        </nav>
        <div className="p-4 border-t border-white/10 text-xs text-white/40 text-center">
          v2.4.1-enterprise
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-full overflow-hidden relative z-0">
        {/* Header */}
        <header className="h-20 flex-shrink-0 border-b border-white/10 glass-panel flex items-center justify-between px-8 z-10">
          <div className="flex items-center gap-3">
            <div className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.8)]"></span>
            </div>
            <span className="text-sm font-medium text-white/80 tracking-wide uppercase">Network Health: Optimal</span>
          </div>
          <div className="flex items-center gap-4">
            <Button variant="ghost" className="text-white/60 hover:text-white hover:bg-white/10" onClick={() => setIsLoggedIn(false)}>
              Sign Out
            </Button>
            <Button className="glass-panel neon-border-blue hover:bg-[#1500ff]/20 text-white transition-all duration-300">
              <Wallet className="mr-2 h-4 w-4" /> Connect Wallet
            </Button>
          </div>
        </header>

        {/* Dashboard Content */}
        <div className="flex-1 overflow-y-auto p-8 space-y-8">
          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <StatCard 
              title="Node State (Φ)" 
              value={data?.nodeState} 
              loading={loading} 
              borderClass="neon-border-blue"
            />
            <StatCard 
              title="Chaos Level (Γ)" 
              value={data?.chaosLevel} 
              loading={loading} 
              borderClass="neon-border-red"
            />
            <StatCard 
              title="Damping (Λ)" 
              value={data?.damping} 
              loading={loading} 
              borderClass="neon-border-purple"
            />
            <StatCard 
              title="Sync Status" 
              value={data?.syncStatus} 
              loading={loading} 
              borderClass="neon-border-gold"
              valueClass={data?.syncStatus === "Synced" ? "text-green-400" : "text-yellow-400"}
            />
          </div>

          {/* Chart Section */}
          <Card className="glass-panel neon-border-purple glow-hover border-t-2">
            <CardHeader>
              <CardTitle className="text-lg font-medium text-white/90 flex items-center gap-2">
                <Activity className="h-5 w-5 text-[#c300ff]" />
                Real-time Stability Chart
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[300px] w-full mt-4">
                {loading ? (
                  <Skeleton className="h-full w-full bg-white/5 rounded-lg" />
                ) : (
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={data?.chartData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" vertical={false} />
                      <XAxis 
                        dataKey="time" 
                        stroke="rgba(255,255,255,0.3)" 
                        tick={{ fill: 'rgba(255,255,255,0.5)', fontSize: 12 }}
                        tickLine={false}
                        axisLine={false}
                      />
                      <YAxis 
                        stroke="rgba(255,255,255,0.3)" 
                        tick={{ fill: 'rgba(255,255,255,0.5)', fontSize: 12 }}
                        tickLine={false}
                        axisLine={false}
                      />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: 'rgba(0,0,0,0.8)', 
                          borderColor: 'rgba(195,0,255,0.5)',
                          borderRadius: '8px',
                          boxShadow: '0 0 15px rgba(195,0,255,0.3)'
                        }} 
                        itemStyle={{ color: '#fff' }}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="stability" 
                        stroke="#c300ff" 
                        strokeWidth={3}
                        dot={false}
                        activeDot={{ r: 6, fill: "#c300ff", stroke: "#fff", strokeWidth: 2 }}
                        style={{ filter: 'drop-shadow(0 0 8px rgba(195,0,255,0.8))' }}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="chaos" 
                        stroke="#ff2600" 
                        strokeWidth={2}
                        strokeDasharray="5 5"
                        dot={false}
                        style={{ filter: 'drop-shadow(0 0 5px rgba(255,38,0,0.5))' }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Table Section */}
          <Card className="glass-panel neon-border-blue glow-hover border-t-2">
            <CardHeader>
              <CardTitle className="text-lg font-medium text-white/90 flex items-center gap-2">
                <Box className="h-5 w-5 text-[#1500ff]" />
                Recent Blocks
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="space-y-3 mt-4">
                  <Skeleton className="h-10 w-full bg-white/5" />
                  <Skeleton className="h-10 w-full bg-white/5" />
                  <Skeleton className="h-10 w-full bg-white/5" />
                  <Skeleton className="h-10 w-full bg-white/5" />
                </div>
              ) : (
                <div className="rounded-md border border-white/10 overflow-hidden mt-4">
                  <Table>
                    <TableHeader className="bg-white/5">
                      <TableRow className="border-white/10 hover:bg-transparent">
                        <TableHead className="text-white/60">Block ID</TableHead>
                        <TableHead className="text-white/60">Timestamp</TableHead>
                        <TableHead className="text-white/60 text-right">Transactions</TableHead>
                        <TableHead className="text-white/60 text-right">Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {data?.recentBlocks.map((block) => (
                        <TableRow key={block.id} className="border-white/10 hover:bg-white/5 transition-colors">
                          <TableCell className="font-mono text-white/80">{block.id}</TableCell>
                          <TableCell className="text-white/60">
                            {new Date(block.timestamp).toLocaleTimeString()}
                          </TableCell>
                          <TableCell className="text-right text-white/80">{block.transactions}</TableCell>
                          <TableCell className="text-right">
                            <Badge 
                              variant="outline" 
                              className={`
                                ${block.status === 'Confirmed' 
                                  ? 'border-green-500/50 text-green-400 bg-green-500/10 shadow-[0_0_10px_rgba(34,197,94,0.2)]' 
                                  : 'border-yellow-500/50 text-yellow-400 bg-yellow-500/10 shadow-[0_0_10px_rgba(234,179,8,0.2)]'}
                              `}
                            >
                              {block.status}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}

function LoginScreen({ onLogin, data }: { onLogin: () => void, data: any }) {
  const [loginMethod, setLoginMethod] = useState<'form' | 'qr'>('form');

  return (
    <div className="flex min-h-screen w-full bg-transparent text-foreground">
      {/* Left Branding Panel (Hidden on mobile) */}
      <div className="hidden lg:flex lg:w-1/2 flex-col justify-between p-12 relative overflow-hidden">
        {/* Background decorative chart */}
        <div className="absolute inset-0 opacity-20 pointer-events-none z-0">
          {data?.chartData && (
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data.chartData}>
                <Line type="monotone" dataKey="stability" stroke="#c300ff" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="chaos" stroke="#ff2600" strokeWidth={1} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          )}
        </div>
        
        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-8">
            <div className="h-10 w-10 rounded-full bg-gradient-to-br from-[#1500ff] to-[#c300ff] flex items-center justify-center shadow-[0_0_20px_rgba(195,0,255,0.6)]">
              <Zap className="h-5 w-5 text-white" />
            </div>
            <h1 className="font-bold text-2xl tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white to-white/60">
              Hyper-Cross Nexus
            </h1>
          </div>
          <h2 className="text-5xl font-bold tracking-tighter text-white mb-6 leading-tight">
            Enterprise-Grade <br/>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#1500ff] via-[#c300ff] to-[#ffae00]">
              Node Stabilization
            </span>
          </h2>
          <p className="text-white/60 text-lg max-w-md">
            Monitor, analyze, and stabilize your blockchain infrastructure with real-time chaos damping and sync telemetry.
          </p>
        </div>

        <div className="relative z-10 glass-panel neon-border-blue p-6 rounded-xl max-w-md">
          <div className="flex items-center gap-4 mb-4">
            <ShieldCheck className="h-8 w-8 text-[#1500ff]" />
            <div>
              <h3 className="text-white font-medium">Institutional Security</h3>
              <p className="text-white/50 text-sm">SOC2 Type II Certified & End-to-End Encrypted</p>
            </div>
          </div>
        </div>
      </div>

      {/* Right Login Panel */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-6 relative z-10">
        <Card className="w-full max-w-md glass-panel neon-border-purple border-t-2 relative overflow-hidden">
          {/* QR Toggle Corner */}
          <div className="absolute top-0 right-0 z-20">
            <button 
              onClick={() => setLoginMethod(loginMethod === 'form' ? 'qr' : 'form')}
              className="p-4 text-white/50 hover:text-white transition-colors bg-white/5 hover:bg-white/10 rounded-bl-xl cursor-pointer"
            >
              {loginMethod === 'form' ? <QrCode size={24} /> : <MonitorSmartphone size={24} />}
            </button>
          </div>

          <CardHeader className="pt-10 pb-6">
            <CardTitle className="text-2xl font-bold text-white">
              {loginMethod === 'form' ? 'Log in to your account' : 'Log in with QR code'}
            </CardTitle>
            <CardDescription className="text-white/50">
              {loginMethod === 'form' ? 'Welcome back to Hyper-Cross Nexus' : 'Scan with the mobile app to log in instantly'}
            </CardDescription>
          </CardHeader>

          <CardContent>
            {loginMethod === 'form' ? (
              <Tabs defaultValue="email" className="w-full">
                <TabsList className="grid w-full grid-cols-2 bg-white/5 mb-6">
                  <TabsTrigger value="email" className="data-[state=active]:bg-white/10 data-[state=active]:text-white text-white/60">Email</TabsTrigger>
                  <TabsTrigger value="phone" className="data-[state=active]:bg-white/10 data-[state=active]:text-white text-white/60">Phone</TabsTrigger>
                </TabsList>
                
                <TabsContent value="email" className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-white/70">Email / Sub-account</Label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-3 h-4 w-4 text-white/40" />
                      <Input id="email" placeholder="Enter email or sub-account" className="pl-10 bg-black/50 border-white/10 text-white placeholder:text-white/30 focus-visible:ring-[#c300ff]" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="password" className="text-white/70">Password</Label>
                      <a href="#" className="text-xs text-[#c300ff] hover:text-[#ffae00] transition-colors">Forgot password?</a>
                    </div>
                    <div className="relative">
                      <Lock className="absolute left-3 top-3 h-4 w-4 text-white/40" />
                      <Input id="password" type="password" placeholder="Enter password" className="pl-10 bg-black/50 border-white/10 text-white placeholder:text-white/30 focus-visible:ring-[#c300ff]" />
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="phone" className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="phone" className="text-white/70">Phone Number</Label>
                    <div className="relative">
                      <Smartphone className="absolute left-3 top-3 h-4 w-4 text-white/40" />
                      <Input id="phone" placeholder="Enter phone number" className="pl-10 bg-black/50 border-white/10 text-white placeholder:text-white/30 focus-visible:ring-[#c300ff]" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="password-phone" className="text-white/70">Password</Label>
                      <a href="#" className="text-xs text-[#c300ff] hover:text-[#ffae00] transition-colors">Forgot password?</a>
                    </div>
                    <div className="relative">
                      <Lock className="absolute left-3 top-3 h-4 w-4 text-white/40" />
                      <Input id="password-phone" type="password" placeholder="Enter password" className="pl-10 bg-black/50 border-white/10 text-white placeholder:text-white/30 focus-visible:ring-[#c300ff]" />
                    </div>
                  </div>
                </TabsContent>

                <Button 
                  onClick={onLogin}
                  className="w-full mt-6 bg-gradient-to-r from-[#1500ff] to-[#c300ff] hover:from-[#1500ff]/80 hover:to-[#c300ff]/80 text-white border-0 shadow-[0_0_15px_rgba(195,0,255,0.4)]"
                >
                  Log in <ArrowRight className="ml-2 h-4 w-4" />
                </Button>

                <div className="mt-6 flex items-center gap-3">
                  <Separator className="flex-1 bg-white/10" />
                  <span className="text-xs text-white/40 uppercase tracking-wider">Or continue with</span>
                  <Separator className="flex-1 bg-white/10" />
                </div>

                <div className="grid grid-cols-2 gap-3 mt-6">
                  <Button variant="outline" className="bg-black/40 border-white/10 text-white hover:bg-white/10">
                    Google
                  </Button>
                  <Button variant="outline" className="bg-black/40 border-white/10 text-white hover:bg-white/10">
                    Apple
                  </Button>
                  <Button variant="outline" className="col-span-2 bg-black/40 border-white/10 text-white hover:bg-white/10 neon-border-gold">
                    <Wallet className="mr-2 h-4 w-4 text-[#ffae00]" /> Web3 Wallet
                  </Button>
                </div>
              </Tabs>
            ) : (
              <div className="flex flex-col items-center justify-center py-8 space-y-6">
                <div className="p-4 bg-white rounded-xl shadow-[0_0_30px_rgba(255,255,255,0.2)]">
                  {/* Mock QR Code using a grid of blocks */}
                  <div className="grid grid-cols-6 gap-1 w-48 h-48">
                    {Array.from({ length: 36 }).map((_, i) => (
                      <div key={i} className={`bg-black rounded-sm ${Math.random() > 0.3 ? 'opacity-100' : 'opacity-0'}`} />
                    ))}
                  </div>
                </div>
                <div className="text-center space-y-2">
                  <p className="text-white/80 font-medium">Open the Hyper-Cross App</p>
                  <p className="text-white/50 text-sm">Scan the QR code to log in instantly</p>
                </div>
                <Button 
                  variant="link" 
                  onClick={() => setLoginMethod('form')}
                  className="text-[#c300ff] hover:text-[#ffae00]"
                >
                  Back to password login
                </Button>
              </div>
            )}
          </CardContent>
          <CardFooter className="flex justify-center border-t border-white/10 pt-6">
            <p className="text-sm text-white/50">
              Don't have an account? <a href="#" className="text-[#c300ff] hover:text-[#ffae00] font-medium transition-colors">Sign up</a>
            </p>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}

function NavItem({ icon, label, active = false }: { icon: React.ReactNode; label: string; active?: boolean }) {
  return (
    <button 
      className={`
        w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-300
        ${active 
          ? 'bg-white/10 text-white shadow-[inset_2px_0_0_#1500ff]' 
          : 'text-white/60 hover:bg-white/5 hover:text-white'}
      `}
    >
      <span className={active ? 'text-[#1500ff] drop-shadow-[0_0_8px_rgba(21,0,255,0.8)]' : ''}>
        {icon}
      </span>
      <span className="font-medium text-sm">{label}</span>
    </button>
  );
}

function StatCard({ 
  title, 
  value, 
  loading, 
  borderClass,
  valueClass = "text-white"
}: { 
  title: string; 
  value?: string; 
  loading: boolean;
  borderClass: string;
  valueClass?: string;
}) {
  return (
    <Card className={`glass-panel ${borderClass} glow-hover border-t-2 overflow-hidden relative group`}>
      {/* Subtle background gradient that appears on hover */}
      <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
      
      <CardHeader className="pb-2 relative z-10">
        <CardTitle className="text-sm font-medium text-white/60 uppercase tracking-wider">
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent className="relative z-10">
        {loading ? (
          <Skeleton className="h-10 w-24 bg-white/10 rounded" />
        ) : (
          <div className={`text-3xl font-bold font-mono tracking-tight ${valueClass}`}>
            {value}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
